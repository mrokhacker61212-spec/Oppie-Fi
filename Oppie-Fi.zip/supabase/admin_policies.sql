-- Oppie-Fi staff admins: listing write access + main-admin-only promotions
-- Run in Supabase SQL Editor while signed in as the project owner.

create or replace function public.is_main_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'super_admin'
  )
  or exists (
    select 1
    from public.super_admins sa
    join auth.users u on lower(u.email) = lower(sa.email)
    where u.id = auth.uid()
  );
$$;

create or replace function public.is_staff()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select public.is_main_admin()
  or exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'admin'
  );
$$;

create or replace function public.promote_to_admin(target_email text)
returns json
language plpgsql
security definer
set search_path = public
as $$
declare
  target_id uuid;
  target_role text;
begin
  if not public.is_main_admin() then
    raise exception 'Only the main admin can create other admins';
  end if;
  if target_email is null or length(trim(target_email)) = 0 then
    raise exception 'Email is required';
  end if;

  select u.id into target_id
  from auth.users u
  where lower(u.email) = lower(trim(target_email))
  limit 1;

  if target_id is null then
    raise exception 'No account found for that email. They must sign up first.';
  end if;

  select p.role into target_role from public.profiles p where p.id = target_id;
  if target_role = 'super_admin' then
    raise exception 'That account is already the main admin';
  end if;

  insert into public.profiles (id, role)
  values (target_id, 'admin')
  on conflict (id) do update
    set role = 'admin'
    where public.profiles.role is distinct from 'super_admin';

  return json_build_object('ok', true, 'id', target_id);
end;
$$;

create or replace function public.demote_admin(target_id uuid)
returns json
language plpgsql
security definer
set search_path = public
as $$
declare
  target_role text;
begin
  if not public.is_main_admin() then
    raise exception 'Only the main admin can remove admins';
  end if;

  select p.role into target_role from public.profiles p where p.id = target_id;
  if target_role = 'super_admin' then
    raise exception 'Cannot remove the main admin';
  end if;

  update public.profiles
  set role = 'user'
  where id = target_id
    and role = 'admin';

  return json_build_object('ok', true);
end;
$$;

create or replace function public.list_staff_accounts()
returns table (id uuid, email text, full_name text, role text)
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_main_admin() then
    raise exception 'Only the main admin can view staff accounts';
  end if;

  return query
  select p.id, u.email::text, p.full_name, p.role
  from public.profiles p
  left join auth.users u on u.id = p.id
  where p.role in ('admin', 'super_admin')
  order by case when p.role = 'super_admin' then 0 else 1 end, u.email;
end;
$$;

revoke all on function public.is_main_admin() from public, anon;
revoke all on function public.is_staff() from public, anon;
revoke all on function public.promote_to_admin(text) from public, anon;
revoke all on function public.demote_admin(uuid) from public, anon;
revoke all on function public.list_staff_accounts() from public, anon;

grant execute on function public.is_main_admin() to authenticated;
grant execute on function public.is_staff() to authenticated;
grant execute on function public.promote_to_admin(text) to authenticated;
grant execute on function public.demote_admin(uuid) to authenticated;
grant execute on function public.list_staff_accounts() to authenticated;

do $$
declare
  t text;
  tables text[] := array[
    'job_listings',
    'courses_and_degrees',
    'freelance_projects',
    'freelancer_profiles',
    'crazy_challenges',
    'local_events',
    'startup_ideas',
    'employers',
    'institutes'
  ];
begin
  foreach t in array tables
  loop
    if to_regclass('public.' || t) is null then
      continue;
    end if;

    execute format('grant select, insert, update, delete on table public.%I to authenticated', t);

    execute format('drop policy if exists %I on public.%I', 'Staff insert ' || t, t);
    execute format('drop policy if exists %I on public.%I', 'Staff update ' || t, t);
    execute format('drop policy if exists %I on public.%I', 'Staff delete ' || t, t);

    execute format(
      'create policy %I on public.%I for insert to authenticated with check (public.is_staff())',
      'Staff insert ' || t, t
    );
    execute format(
      'create policy %I on public.%I for update to authenticated using (public.is_staff()) with check (public.is_staff())',
      'Staff update ' || t, t
    );
    execute format(
      'create policy %I on public.%I for delete to authenticated using (public.is_staff())',
      'Staff delete ' || t, t
    );
  end loop;
end $$;
