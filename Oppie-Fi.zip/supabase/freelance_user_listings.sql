-- Allow signed-in users to post freelance projects and freelancer profiles.
-- Run in the Supabase SQL Editor (after admin_policies.sql).

alter table public.freelance_projects
  add column if not exists created_by uuid references auth.users (id);

alter table public.freelancer_profiles
  add column if not exists created_by uuid references auth.users (id);

drop policy if exists "Users insert freelance_projects" on public.freelance_projects;
drop policy if exists "Users update own freelance_projects" on public.freelance_projects;
drop policy if exists "Users delete own freelance_projects" on public.freelance_projects;
drop policy if exists "Users insert freelancer_profiles" on public.freelancer_profiles;
drop policy if exists "Users update own freelancer_profiles" on public.freelancer_profiles;
drop policy if exists "Users delete own freelancer_profiles" on public.freelancer_profiles;

create policy "Users insert freelance_projects"
  on public.freelance_projects for insert to authenticated
  with check (created_by = auth.uid());

create policy "Users update own freelance_projects"
  on public.freelance_projects for update to authenticated
  using (created_by = auth.uid())
  with check (created_by = auth.uid());

create policy "Users delete own freelance_projects"
  on public.freelance_projects for delete to authenticated
  using (created_by = auth.uid());

create policy "Users insert freelancer_profiles"
  on public.freelancer_profiles for insert to authenticated
  with check (created_by = auth.uid());

create policy "Users update own freelancer_profiles"
  on public.freelancer_profiles for update to authenticated
  using (created_by = auth.uid())
  with check (created_by = auth.uid());

create policy "Users delete own freelancer_profiles"
  on public.freelancer_profiles for delete to authenticated
  using (created_by = auth.uid());
