import { useState, useEffect, useMemo } from "react";
import { supabase, runQuery } from "./lib/supabase";
import { isAdmin, isSuperAdmin } from "./lib/auth";
import { filterAndSearch, buildFilterDefs, getSearchHint } from "./lib/browse";
import { deleteListing } from "./lib/admin";
import { listingKindFor } from "./constants/listingFields";
import FilterBar from "./components/FilterBar";
import ListingEditor, { AdminCardActions } from "./components/ListingEditor";
import AdminDock from "./components/AdminDock";
import ManageAdmins from "./components/ManageAdmins";

const SECTIONS = [
  { id: "jobs",         label: "Jobs",             icon: "💼", color: "#00E5FF", glow: "#00E5FF33", sub: "Every kind of job. Remote, onsite, everywhere."          },
  { id: "education",    label: "Education",         icon: "🎓", color: "#B388FF", glow: "#B388FF33", sub: "Scholarships, admissions, courses & foreign programs."    },
  { id: "freelance",    label: "Freelance",          icon: "⚡", color: "#FFD740", glow: "#FFD74033", sub: "Browse projects to take on, or find talent to hire."      },
  { id: "challenges",   label: "Crazy Challenges",   icon: "🔥", color: "#FF6D00", glow: "#FF6D0033", sub: "High-risk, high-reward. For the bold."                    },
  { id: "events",       label: "Events",             icon: "📍", color: "#69FF47", glow: "#69FF4733", sub: "Discover events by name, place, and category."            },
  { id: "entrepreneur", label: "Entrepreneur Hub",   icon: "🚀", color: "#FF4081", glow: "#FF408133", sub: "Post wild ideas. Find co-founders. Build something."      },
];
const sectionFor = (id) => SECTIONS.find(s => s.id === id);

const GLOBAL_CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:ital,wght@0,300;0,400;0,500;0,600;1,400&display=swap');
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: #0D0D0F; font-family: 'DM Sans', sans-serif; color: #fff; overflow: hidden; }
  ::-webkit-scrollbar { width: 3px; } ::-webkit-scrollbar-track { background: transparent; } ::-webkit-scrollbar-thumb { background: #2a2a2a; border-radius: 2px; }
  button, a { font-family: 'DM Sans', sans-serif; }
  .oppiefi-heading { font-family: 'Syne', sans-serif; }
  .nav-item { display: flex; align-items: center; gap: 11px; padding: 9px 12px; border-radius: 10px; border: none; border-left: 2px solid transparent; background: transparent; color: #3a3a3a; cursor: pointer; font-size: 13px; font-weight: 500; text-align: left; width: 100%; transition: color 0.15s, background 0.15s, border-color 0.15s; font-family: 'DM Sans', sans-serif; }
  .nav-item:hover { color: #888; background: #ffffff08; }
  .nav-item.active { color: #fff; font-weight: 600; }
  .nav-icon { font-size: 16px; flex-shrink: 0; transition: transform 0.2s; }
  .nav-item.active .nav-icon { transform: scale(1.15); }
  .nav-dot { width: 5px; height: 5px; border-radius: 50%; margin-left: auto; flex-shrink: 0; opacity: 0; transition: opacity 0.2s; }
  .nav-item.active .nav-dot { opacity: 1; }
  .oppie-card { background: #111114; border: 1px solid #1e1e22; border-radius: 14px; padding: 20px; cursor: pointer; transition: transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease, background 0.2s ease; position: relative; overflow: hidden; }
  .oppie-card:hover { transform: translateY(-3px); background: #16161a; }
  .tag { background: #1e1e22; color: #555; font-size: 11px; padding: 3px 9px; border-radius: 20px; white-space: nowrap; font-family: 'DM Sans', sans-serif; }
  @keyframes shimmer { 0% { background-position: -400px 0; } 100% { background-position: 400px 0; } }
  .shimmer { background: linear-gradient(90deg, #111114 25%, #1a1a1e 50%, #111114 75%); background-size: 400px 100%; animation: shimmer 1.4s infinite; border-radius: 8px; }
  @keyframes fadeUp { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
  .fade-up { animation: fadeUp 0.35s ease forwards; }
  @keyframes overlayIn { from { opacity: 0; transform: scale(0.98) translateY(10px); } to { opacity: 1; transform: scale(1) translateY(0); } }
  .overlay-in { animation: overlayIn 0.25s cubic-bezier(0.16,1,0.3,1) forwards; }
  .card-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(295px, 1fr)); gap: 14px; }
  .search-input { background: transparent; border: none; outline: none; color: #aaa; font-size: 13px; width: 100%; font-family: 'DM Sans', sans-serif; }
  .search-input::placeholder { color: #333; }
  .dl { font-size: 10px; letter-spacing: 1.5px; color: #333; font-weight: 600; margin-bottom: 10px; text-transform: uppercase; }
  .divider { height: 1px; background: #1e1e22; margin: 24px 0; }
  .irow { display: flex; align-items: flex-start; gap: 14px; padding: 13px 18px; border-bottom: 1px solid #18181c; }
  .irow:last-child { border-bottom: none; }

`;

function parseTags(v) { if (!v) return []; if (Array.isArray(v)) return v; return v.split(",").map(t => t.trim()).filter(Boolean); }

/** Pathway fields use "Step 1: … Step 2: …" — never split on commas inside a step */
function parseSteps(v) {
  if (!v) return [];
  if (Array.isArray(v)) return v.map((s) => String(s).trim()).filter(Boolean);
  const text = String(v).replace(/\s+/g, " ").trim();
  const byStepLabel = text.split(/(?=Step\s+\d+\s*:)/i).map((s) => s.trim()).filter(Boolean);
  if (byStepLabel.length > 1) return byStepLabel;
  const byNewline = String(v).split(/\n+/).map((s) => s.trim()).filter(Boolean);
  if (byNewline.length > 1) return byNewline;
  return text ? [text] : [];
}

function StepLine({ text, color }) {
  const m = text.match(/^(Step\s+\d+\s*:)\s*(.*)$/i);
  if (!m) return <span>{text}</span>;
  return (
    <>
      <span style={{ color, fontWeight: 700 }}>{m[1]} </span>
      <span style={{ color: "#ccc" }}>{m[2]}</span>
    </>
  );
}
function Tag({ text, color }) {
  if (color) return <span style={{ background: color + "18", color, fontSize: 11, padding: "3px 9px", borderRadius: 20, whiteSpace: "nowrap" }}>{text}</span>;
  return <span className="tag">{text}</span>;
}
function Divider() { return <div className="divider" />; }
function DL({ text }) { return <div className="dl">{text}</div>; }
function InfoRow({ icon, label, value }) {
  if (!value) return null;
  return <div className="irow"><span style={{ fontSize: 17, flexShrink: 0, width: 26, textAlign: "center" }}>{icon}</span><div style={{ flex: 1 }}><div style={{ fontSize: 10, color: "#444", marginBottom: 2 }}>{label}</div><div style={{ fontSize: 14, color: "#ccc", fontWeight: 500 }}>{value}</div></div></div>;
}
function StepsBlock({ steps, color, title = "HOW TO APPLY" }) {
  if (!steps?.length) return null;
  return (
    <>
      <DL text={title} />
      <div
        style={{
          marginBottom: 24,
          padding: "16px 18px",
          background: color + "0c",
          borderLeft: `3px solid ${color}`,
          borderRadius: "0 10px 10px 0",
          fontSize: 14,
          lineHeight: 1.85,
        }}
      >
        {steps.map((text, i) => (
          <div key={i} style={{ marginBottom: i < steps.length - 1 ? 12 : 0 }}>
            <StepLine text={text} color={color} />
          </div>
        ))}
      </div>
    </>
  );
}

function SkeletonCard() {
  return <div className="oppie-card" style={{ display: "flex", flexDirection: "column", gap: 12 }}><div className="shimmer" style={{ height: 14, width: "60%" }} /><div className="shimmer" style={{ height: 10, width: "40%" }} /><div className="shimmer" style={{ height: 32, width: "100%", marginTop: 4 }} /><div style={{ display: "flex", gap: 8, marginTop: 4 }}><div className="shimmer" style={{ height: 22, width: 60, borderRadius: 20 }} /><div className="shimmer" style={{ height: 22, width: 80, borderRadius: 20 }} /></div></div>;
}
function LoadingGrid() { return <div className="card-grid">{[1,2,3,4,5,6].map(i => <SkeletonCard key={i} />)}</div>; }
function ErrorState({ msg, onRetry }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", padding: "80px 40px", gap: 12 }}>
      <span style={{ fontSize: 36 }}>⚠</span>
      <span style={{ fontSize: 14, color: "#555", textAlign: "center", maxWidth: 360 }}>{msg}</span>
      {onRetry && (
        <button type="button" onClick={onRetry} style={{ marginTop: 8, background: "#111114", border: "1px solid #1e1e22", borderRadius: 10, padding: "10px 18px", color: "#00E5FF", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
          Retry loading
        </button>
      )}
    </div>
  );
}
function EmptyState({ msg }) {
  return <div style={{ display: "flex", flexDirection: "column", alignItems: "center", padding: "80px 40px", gap: 12 }}><span style={{ fontSize: 40 }}>🔭</span><span className="oppiefi-heading" style={{ fontSize: 15, color: "#fff" }}>Nothing here yet</span><span style={{ fontSize: 13, color: "#444", textAlign: "center", maxWidth: 320 }}>{msg}</span></div>;
}

// ── DETAIL SHELL ─────────────────────────────────────────────────────
function DetailShell({ accent, onClose, children, admin }) {
  const [saved, setSaved] = useState(false);
  useEffect(() => { const fn = e => { if (e.key === "Escape") onClose(); }; window.addEventListener("keydown", fn); return () => window.removeEventListener("keydown", fn); }, [onClose]);
  return (
    <div className="overlay-in" style={{ position: "fixed", inset: 0, zIndex: 100, background: "#0D0D0F", display: "flex", flexDirection: "column" }}>
      <div style={{ height: 56, background: "#0A0A0C", borderBottom: "1px solid #18181c", display: "flex", alignItems: "center", padding: "0 24px", gap: 10, flexShrink: 0 }}>
        <button onClick={onClose} style={{ background: "#18181c", border: "1px solid #1e1e22", borderRadius: 8, padding: "6px 14px", color: "#aaa", fontSize: 13, cursor: "pointer" }}>← Back</button>
        <div style={{ flex: 1 }} />
        {admin?.enabled && (
          <>
            <button type="button" onClick={admin.onEdit} style={{ background: "#18181c", border: "1px solid #00E5FF55", borderRadius: 8, padding: "6px 14px", color: "#00E5FF", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>Edit</button>
            <button type="button" onClick={admin.onDelete} style={{ background: "#18181c", border: "1px solid #FF6B6B55", borderRadius: 8, padding: "6px 14px", color: "#FF6B6B", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>Delete</button>
          </>
        )}
        <button onClick={() => setSaved(s => !s)} style={{ background: saved ? accent + "22" : "#18181c", border: `1px solid ${saved ? accent + "55" : "#1e1e22"}`, borderRadius: 8, padding: "6px 14px", color: saved ? accent : "#555", fontSize: 13, cursor: "pointer", transition: "all 0.2s" }}>{saved ? "✦ Saved" : "✧ Save"}</button>
        <button onClick={() => navigator.clipboard?.writeText(window.location.href)} style={{ background: "#18181c", border: "1px solid #1e1e22", borderRadius: 8, padding: "6px 14px", color: "#555", fontSize: 13, cursor: "pointer" }}>↗ Share</button>
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: "40px 0 80px" }}>
        <div style={{ maxWidth: 700, margin: "0 auto", padding: "0 28px" }}>{children}</div>
      </div>
    </div>
  );
}

// ── DETAIL VIEWS ─────────────────────────────────────────────────────
function JobDetail({ o, accent, onClose, admin }) {
  return (
        <DetailShell accent={accent} onClose={onClose} admin={admin}>
      <Tag text={o.job_type === "remote" ? "🌐 Remote" : `📍 ${o.employers?.location || "Onsite"}`} color={accent} />
      <h1 className="oppiefi-heading" style={{ fontSize: 32, fontWeight: 800, color: "#fff", letterSpacing: "-1px", margin: "12px 0 6px", lineHeight: 1.15 }}>{o.title}</h1>
      <div style={{ fontSize: 15, color: "#555", marginBottom: 24 }}>{o.employers?.name} · {o.employment_type}</div>
      <Divider />
      <DL text="AT A GLANCE" />
      <div style={{ background: "#111114", border: "1px solid #1e1e22", borderRadius: 12, overflow: "hidden", marginBottom: 28 }}>
        <InfoRow icon="💰" label="Pay" value={o.pay} />
        <InfoRow icon="🕐" label="Hours" value={o.hours} />
        <InfoRow icon="📅" label="Start Date" value={o.start_date} />
        <InfoRow icon="⏱" label="Hiring Timeline" value={o.hiring_timeline} />
        <InfoRow icon="🎯" label="Experience" value={o.experience_required ? "Required" : "Not required"} />
        <InfoRow icon="✨" label="Perks" value={o.perks} />
        <InfoRow icon="📨" label="How to Apply" value={o.application_method} />
        <InfoRow icon="📬" label="Contact / Link" value={o.application_link_or_contact} />
      </div>
      {o.experience_details && <><DL text="EXPERIENCE DETAILS" /><p style={{ fontSize: 14, color: "#777", lineHeight: 1.8, marginBottom: 24 }}>{o.experience_details}</p></>}
      <Divider />
      <a href={o.application_link_or_contact || `mailto:${o.employers?.contact_email}`} target="_blank" rel="noreferrer" style={{ display: "block", textAlign: "center", background: accent, color: "#000", borderRadius: 12, padding: "16px", fontSize: 16, fontWeight: 800, textDecoration: "none", fontFamily: "'Syne', sans-serif" }}>Apply for this Role →</a>
    </DetailShell>
  );
}

function EduDetail({ o, accent, onClose, admin }) {
  const steps = parseSteps(o.pathway);
  const docs = parseTags(o.documents_needed);
  return (
        <DetailShell accent={accent} onClose={onClose} admin={admin}>
      <div style={{ background: accent + "18", borderRadius: 6, padding: "4px 10px", display: "inline-block", marginBottom: 14 }}>
        <span style={{ fontSize: 10, color: accent, fontWeight: 700, letterSpacing: "1px" }}>{(o.degree_type || "COURSE").toUpperCase()}</span>
      </div>
      <h1 className="oppiefi-heading" style={{ fontSize: 32, fontWeight: 800, color: "#fff", letterSpacing: "-1px", margin: "0 0 8px", lineHeight: 1.15 }}>{o.course_name || o.title}</h1>
      <div style={{ fontSize: 15, color: "#555", marginBottom: 24 }}>{o.institutes?.name} · {o.institutes?.location}</div>
      <Divider />
      <DL text="KEY DETAILS" />
      <div style={{ background: "#111114", border: "1px solid #1e1e22", borderRadius: 12, overflow: "hidden", marginBottom: 28 }}>
        <InfoRow icon="⏳" label="Duration" value={o.duration} />
        <InfoRow icon="💰" label="Cost" value={o.price} />
        <InfoRow icon="🎓" label="Financial Aid" value={o.financial_aid_available ? (o.financial_aid_details || "Available") : null} />
        <InfoRow icon="📅" label="Application Deadline" value={o.application_deadline ? new Date(o.application_deadline).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" }) : "Rolling"} />
        <InfoRow icon="🚀" label="Intake Date" value={o.intake_date ? new Date(o.intake_date).toLocaleDateString("en-US", { year: "numeric", month: "long" }) : null} />
        <InfoRow icon="💺" label="Available Seats" value={o.available_seats ? String(o.available_seats) : null} />
        <InfoRow icon="📋" label="Entry Requirements" value={o.entry_requirements} />
        <InfoRow icon="📞" label="Contact" value={o.institutes?.contact_email} />
      </div>
      <StepsBlock steps={steps} color={accent} title="HOW TO APPLY" />
      {docs.length > 0 && <><Divider /><DL text="DOCUMENTS NEEDED" />{docs.map((d, i) => <div key={i} style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 8 }}><div style={{ width: 6, height: 6, borderRadius: "50%", background: accent, flexShrink: 0 }} /><span style={{ fontSize: 14, color: "#777" }}>{d}</span></div>)}<div style={{ marginBottom: 24 }} /></>}
      <Divider />
      <a href={o.institutes?.website || "#"} target="_blank" rel="noreferrer" style={{ display: "block", textAlign: "center", background: accent, color: "#000", borderRadius: 12, padding: "16px", fontSize: 16, fontWeight: 800, textDecoration: "none", fontFamily: "'Syne', sans-serif" }}>Apply Now →</a>
    </DetailShell>
  );
}

function ProjectDetail({ o, accent, onClose, admin }) {
  const [pitch, setPitch] = useState(""); const [sending, setSending] = useState(false); const [sent, setSent] = useState(false);
  const skills = parseTags(o.skills_required);
  const send = async () => { if (!pitch.trim()) return; setSending(true); await supabase.from("pitches").insert({ opportunity_id: String(o.id), opportunity_type: "freelance_project", message: pitch.trim() }); setSending(false); setSent(true); };
  return (
        <DetailShell accent={accent} onClose={onClose} admin={admin}>
      <div style={{ fontSize: 10, color: accent, fontWeight: 700, letterSpacing: "1px", marginBottom: 14 }}>📋 PROJECT BRIEF</div>
      <h1 className="oppiefi-heading" style={{ fontSize: 32, fontWeight: 800, color: "#fff", letterSpacing: "-1px", margin: "0 0 8px", lineHeight: 1.15 }}>{o.title}</h1>
      <div style={{ fontSize: 14, color: "#555", marginBottom: 24 }}>{o.client_name}{o.client_response_rate ? ` · ${o.client_response_rate} response rate` : ""}{o.client_hires_before ? " · Has hired before ✓" : ""}</div>
      <Divider />
      <DL text="PROJECT DETAILS" />
      <div style={{ background: "#111114", border: "1px solid #1e1e22", borderRadius: 12, overflow: "hidden", marginBottom: 28 }}>
        <InfoRow icon="💰" label="Budget" value={o.budget_amount ? `${o.budget_amount} (${o.budget_type})` : null} />
        <InfoRow icon="⏱" label="Duration" value={o.project_duration} />
        <InfoRow icon="📅" label="Deadline" value={o.deadline ? new Date(o.deadline).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" }) : null} />
        <InfoRow icon="📨" label="How to Apply" value={o.application_method} />
        <InfoRow icon="📬" label="Client Contact" value={o.client_contact} />
      </div>
      <DL text="FULL BRIEF" />
      <p style={{ fontSize: 15, color: "#888", lineHeight: 1.8, marginBottom: 24 }}>{o.description}</p>
      {skills.length > 0 && <><DL text="SKILLS REQUIRED" /><div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 24 }}>{skills.map(s => <Tag key={s} text={s} color={accent} />)}</div></>}
      <Divider />
      <DL text="YOUR PITCH" />
      {sent
        ? <div style={{ background: accent + "18", border: `1px solid ${accent}44`, borderRadius: 12, padding: 24, textAlign: "center" }}><div style={{ fontSize: 28, marginBottom: 8 }}>✦</div><div className="oppiefi-heading" style={{ fontSize: 16, color: accent }}>Pitch Sent!</div><div style={{ fontSize: 13, color: "#555", marginTop: 4 }}>The client will review and get in touch.</div></div>
        : <><textarea value={pitch} onChange={e => setPitch(e.target.value)} placeholder="Introduce yourself. Why are you the right fit?" rows={5} style={{ width: "100%", background: "#111114", border: `1px solid ${pitch ? accent + "44" : "#1e1e22"}`, borderRadius: 12, padding: "14px 16px", color: "#ccc", fontSize: 14, lineHeight: 1.7, fontFamily: "'DM Sans', sans-serif", resize: "none", outline: "none" }} /><button onClick={send} disabled={sending || !pitch.trim()} style={{ marginTop: 10, width: "100%", background: pitch.trim() ? accent : "#1e1e22", color: pitch.trim() ? "#000" : "#444", border: "none", borderRadius: 12, padding: "14px", fontSize: 15, fontWeight: 700, cursor: pitch.trim() ? "pointer" : "default", fontFamily: "'Syne', sans-serif" }}>{sending ? "Sending..." : "Send Pitch →"}</button></>
      }
    </DetailShell>
  );
}

function FreelancerDetail({ o, accent, onClose, admin }) {
  const [msg, setMsg] = useState(""); const [sending, setSending] = useState(false); const [sent, setSent] = useState(false);
  const skills = parseTags(o.other_skills || o.skills);
  const send = async () => { if (!msg.trim()) return; setSending(true); await supabase.from("pitches").insert({ opportunity_id: String(o.id), opportunity_type: "freelancer_message", message: msg.trim() }); setSending(false); setSent(true); };
  return (
        <DetailShell accent={accent} onClose={onClose} admin={admin}>
      <div style={{ display: "flex", gap: 20, alignItems: "flex-start", marginBottom: 28 }}>
        <div style={{ width: 64, height: 64, borderRadius: 14, background: accent + "22", border: `1px solid ${accent}33`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 26, flexShrink: 0 }}>👤</div>
        <div>
          <div style={{ fontSize: 10, color: accent, fontWeight: 700, letterSpacing: "1px", marginBottom: 6 }}>FREELANCER</div>
          <h1 className="oppiefi-heading" style={{ fontSize: 26, fontWeight: 800, color: "#fff", letterSpacing: "-0.8px", lineHeight: 1.2, marginBottom: 4 }}>{o.name || o.tagline}</h1>
          {o.top_skill && <div style={{ fontSize: 14, color: accent, fontWeight: 600 }}>{o.top_skill}</div>}
        </div>
      </div>
      <Divider />
      <DL text="OVERVIEW" />
      <div style={{ background: "#111114", border: "1px solid #1e1e22", borderRadius: 12, overflow: "hidden", marginBottom: 28 }}>
        <InfoRow icon="💰" label="Rate" value={o.hourly_rate} />
        <InfoRow icon="📅" label="Availability" value={o.availability} />
        <InfoRow icon="⏱" label="Experience" value={o.experience_years} />
        <InfoRow icon="📨" label="Preferred Contact" value={o.preferred_contact} />
        <InfoRow icon="📬" label="Contact" value={o.contact_value} />
      </div>
      {o.bio && <><DL text="ABOUT" /><p style={{ fontSize: 15, color: "#888", lineHeight: 1.8, marginBottom: 24 }}>{o.bio}</p></>}
      {skills.length > 0 && <><DL text="SKILLS" /><div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 24 }}>{skills.map(s => <Tag key={s} text={s} color={accent} />)}</div></>}
      {o.portfolio_link && <><Divider /><DL text="PORTFOLIO" /><a href={o.portfolio_link} target="_blank" rel="noreferrer" style={{ display: "flex", alignItems: "center", gap: 12, background: "#111114", border: `1px solid ${accent}33`, borderRadius: 12, padding: "16px 20px", textDecoration: "none", marginBottom: 24 }}><span style={{ fontSize: 20 }}>🔗</span><div><div style={{ fontSize: 14, color: "#fff", fontWeight: 600 }}>View Portfolio</div><div style={{ fontSize: 12, color: "#444" }}>{o.portfolio_link}</div></div><span style={{ marginLeft: "auto", color: accent, fontSize: 16 }}>↗</span></a></>}
      <Divider />
      <DL text="SEND A MESSAGE" />
      {sent
        ? <div style={{ background: accent + "18", border: `1px solid ${accent}44`, borderRadius: 12, padding: 24, textAlign: "center" }}><div style={{ fontSize: 28, marginBottom: 8 }}>✦</div><div className="oppiefi-heading" style={{ fontSize: 16, color: accent }}>Message Sent!</div><div style={{ fontSize: 13, color: "#555", marginTop: 4 }}>They'll get back to you soon.</div></div>
        : <><textarea value={msg} onChange={e => setMsg(e.target.value)} placeholder="Describe what you need help with..." rows={4} style={{ width: "100%", background: "#111114", border: `1px solid ${msg ? accent + "44" : "#1e1e22"}`, borderRadius: 12, padding: "14px 16px", color: "#ccc", fontSize: 14, lineHeight: 1.7, fontFamily: "'DM Sans', sans-serif", resize: "none", outline: "none" }} /><button onClick={send} disabled={sending || !msg.trim()} style={{ marginTop: 10, width: "100%", background: msg.trim() ? accent : "#1e1e22", color: msg.trim() ? "#000" : "#444", border: "none", borderRadius: 12, padding: "14px", fontSize: 15, fontWeight: 700, cursor: msg.trim() ? "pointer" : "default", fontFamily: "'Syne', sans-serif" }}>{sending ? "Sending..." : "Send Message →"}</button></>
      }
    </DetailShell>
  );
}

function ChallengeDetail({ o, accent, onClose, admin }) {
  const riskColor = { low: "#69FF47", medium: "#FFD740", high: "#FF6D00", "very high": "#FF4081" };
  const rc = riskColor[o.risk_level?.toLowerCase()] || accent;
  const flames = { low: 1, medium: 2, high: 3, "very high": 5 }[o.risk_level?.toLowerCase()] || 3;
  return (
        <DetailShell accent={accent} onClose={onClose} admin={admin}>
      <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 14 }}>
        <span style={{ fontSize: 10, color: accent, fontWeight: 700, letterSpacing: "1.5px" }}>CHALLENGE</span>
        <span style={{ background: rc + "22", color: rc, fontSize: 11, padding: "3px 10px", borderRadius: 20, fontWeight: 600 }}>{"🔥".repeat(flames)} {o.risk_level} Risk</span>
        {o.verified && <span style={{ background: "#69FF4722", color: "#69FF47", fontSize: 11, padding: "3px 10px", borderRadius: 20, fontWeight: 600 }}>✓ Verified</span>}
      </div>
      <h1 className="oppiefi-heading" style={{ fontSize: 32, fontWeight: 800, color: "#fff", letterSpacing: "-1px", margin: "0 0 10px", lineHeight: 1.15 }}>{o.title}</h1>
      <div className="oppiefi-heading" style={{ fontSize: 28, fontWeight: 800, color: accent, marginBottom: 24 }}>{o.reward_amount}</div>
      <Divider />
      <DL text="WHAT THIS INVOLVES" />
      <p style={{ fontSize: 15, color: "#888", lineHeight: 1.8, marginBottom: 28 }}>{o.description}</p>
      <DL text="DETAILS" />
      <div style={{ background: "#120a06", border: "1px solid #2a1808", borderRadius: 12, overflow: "hidden", marginBottom: 28 }}>
        <InfoRow icon="📍" label="Location" value={o.location} />
        <InfoRow icon="⏱" label="Duration" value={o.duration} />
        <InfoRow icon="🏆" label="Reward" value={`${o.reward_amount} (${o.reward_type})`} />
        <InfoRow icon="🛠" label="Requirements" value={o.requirements} />
        <InfoRow icon="🚪" label="Exit Conditions" value={o.exit_conditions} />
        <InfoRow icon="👥" label="Past Participants" value={o.past_participants ? `${o.past_participants} people have done this` : null} />
        <InfoRow icon="📨" label="How to Apply" value={o.how_to_apply} />
      </div>
      {o.verified && <div style={{ background: "#0a1208", border: "1px solid #69FF4722", borderRadius: 12, padding: "16px 20px", display: "flex", gap: 14, alignItems: "center", marginBottom: 24 }}><span style={{ fontSize: 24 }}>✓</span><div><div style={{ fontSize: 13, fontWeight: 700, color: "#69FF47" }}>Verified by Oppie-Fi</div><div style={{ fontSize: 12, color: "#334433", marginTop: 2 }}>This challenge has been vetted. Reward and conditions confirmed.</div></div></div>}
      <a href={o.application_link || "#"} target="_blank" rel="noreferrer" style={{ display: "block", textAlign: "center", background: "linear-gradient(135deg, #FF6D00, #FF4500)", color: "#fff", borderRadius: 12, padding: "16px", fontSize: 16, fontWeight: 800, textDecoration: "none", fontFamily: "'Syne', sans-serif" }}>Accept This Challenge →</a>
    </DetailShell>
  );
}

function EventDetail({ o, accent, onClose, admin }) {
  const dateStr = o.event_date ? new Date(o.event_date).toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" }) : null;
  return (
        <DetailShell accent={accent} onClose={onClose} admin={admin}>
      <div style={{ fontSize: 10, color: accent, fontWeight: 700, letterSpacing: "1.5px", marginBottom: 14 }}>EVENT</div>
      <h1 className="oppiefi-heading" style={{ fontSize: 32, fontWeight: 800, color: "#fff", letterSpacing: "-1px", margin: "0 0 8px", lineHeight: 1.15 }}>{o.title}</h1>
      <div style={{ fontSize: 14, color: "#555", marginBottom: 24 }}>{dateStr}{o.event_time ? ` · ${o.event_time}` : ""}</div>
      <Divider />
      <DL text="EVENT DETAILS" />
      <div style={{ background: "#0E110D", border: `1px solid ${accent}22`, borderRadius: 12, overflow: "hidden", marginBottom: 28 }}>
        <InfoRow icon="📍" label="Location" value={o.location} />
        <InfoRow icon="🎟" label="Admission" value={o.is_free ? "Free Entry" : o.price} />
        <InfoRow icon="👥" label="For" value={o.target_audience} />
        <InfoRow icon="🏷" label="Category" value={o.category_tag} />
        <InfoRow icon="📬" label="Contact" value={o.contact} />
      </div>
      {o.description && <><DL text="ABOUT" /><p style={{ fontSize: 15, color: "#888", lineHeight: 1.8, marginBottom: 24 }}>{o.description}</p></>}
      {o.registration_link && <a href={o.registration_link} target="_blank" rel="noreferrer" style={{ display: "block", textAlign: "center", background: accent, color: "#000", borderRadius: 12, padding: "16px", fontSize: 16, fontWeight: 800, textDecoration: "none", fontFamily: "'Syne', sans-serif" }}>RSVP / Register →</a>}
    </DetailShell>
  );
}

function StartupDetail({ o, accent, onClose, admin }) {
  const [msg, setMsg] = useState(""); const [sending, setSending] = useState(false); const [sent, setSent] = useState(false);
  const roles = parseTags(o.roles_needed);
  const send = async () => { if (!msg.trim()) return; setSending(true); await supabase.from("pitches").insert({ opportunity_id: String(o.id), opportunity_type: "startup_idea", message: msg.trim() }); setSending(false); setSent(true); };
  return (
        <DetailShell accent={accent} onClose={onClose} admin={admin}>
      <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 14 }}>
        <Tag text={o.stage || "Idea"} color={accent} />
        {o.team_space_status && <span style={{ fontSize: 11, color: o.team_space_status === "active" ? "#69FF47" : "#444" }}>{o.team_space_status === "active" ? "🟢 Active team" : "⚪ Not started"}</span>}
      </div>
      <h1 className="oppiefi-heading" style={{ fontSize: 32, fontWeight: 800, color: "#fff", letterSpacing: "-1px", margin: "0 0 24px", lineHeight: 1.15 }}>{o.title}</h1>
      <Divider />
      <DL text="THE PITCH" />
      <p style={{ fontSize: 15, color: "#888", lineHeight: 1.8, marginBottom: 28 }}>{o.description}</p>
      <DL text="FOUNDER" />
      <div style={{ background: "#111114", border: "1px solid #1e1e22", borderRadius: 12, padding: "16px 20px", display: "flex", gap: 14, alignItems: "center", marginBottom: 28 }}>
        <div style={{ width: 42, height: 42, borderRadius: 10, background: accent + "22", border: `1px solid ${accent}33`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, flexShrink: 0 }}>👤</div>
        <div><div style={{ fontSize: 15, fontWeight: 600, color: "#fff" }}>{o.founder_name || "Anonymous"}</div>{o.founder_bio && <div style={{ fontSize: 12, color: "#555", marginTop: 2 }}>{o.founder_bio}</div>}</div>
      </div>
      <DL text="PROJECT INFO" />
      <div style={{ background: "#111114", border: "1px solid #1e1e22", borderRadius: 12, overflow: "hidden", marginBottom: 28 }}>
        <InfoRow icon="🏷" label="Market / Industry" value={o.industry} />
        <InfoRow icon="⏱" label="Time Commitment" value={o.time_commitment} />
        <InfoRow icon="💰" label="Pay" value={o.pay_now} />
        <InfoRow icon="📈" label="Equity" value={o.equity_offer} />
        <InfoRow icon="📬" label="Contact" value={o.founder_contact} />
      </div>
      {roles.length > 0 && <><DL text="ROLES NEEDED" /><div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 28 }}>{roles.map(r => <Tag key={r} text={r} color={accent} />)}</div></>}
      <Divider />
      <StepsBlock
        steps={[
          "Submit your intro below",
          "Founder reviews your message",
          `Connect via ${o.founder_contact || "email"}`,
          "Agree on equity or contribution terms",
          "Start building together 🚀",
        ]}
        color={accent}
        title="WHAT HAPPENS AFTER YOU APPLY"
      />
      <Divider />
      <DL text="APPLY TO JOIN" />
      {sent
        ? <div style={{ background: accent + "18", border: `1px solid ${accent}44`, borderRadius: 12, padding: 24, textAlign: "center" }}><div style={{ fontSize: 28, marginBottom: 8 }}>🚀</div><div className="oppiefi-heading" style={{ fontSize: 16, color: accent }}>Application Sent!</div><div style={{ fontSize: 13, color: "#555", marginTop: 4 }}>The founder will reach out soon.</div></div>
        : <><textarea value={msg} onChange={e => setMsg(e.target.value)} placeholder="Who are you? What role would you fill? Why does this idea excite you?" rows={5} style={{ width: "100%", background: "#111114", border: `1px solid ${msg ? accent + "44" : "#1e1e22"}`, borderRadius: 12, padding: "14px 16px", color: "#ccc", fontSize: 14, lineHeight: 1.7, fontFamily: "'DM Sans', sans-serif", resize: "none", outline: "none" }} /><button onClick={send} disabled={sending || !msg.trim()} style={{ marginTop: 10, width: "100%", background: msg.trim() ? accent : "#1e1e22", color: msg.trim() ? "#fff" : "#444", border: "none", borderRadius: 12, padding: "14px", fontSize: 15, fontWeight: 700, cursor: msg.trim() ? "pointer" : "default", fontFamily: "'Syne', sans-serif" }}>{sending ? "Sending..." : "Apply to Join →"}</button></>
      }
    </DetailShell>
  );
}

// ── LAYOUT COMPONENTS ────────────────────────────────────────────────
function Sidebar({ active, setActive }) {
  const sec = sectionFor(active);
  return (
    <aside style={{ width: 200, background: "#0A0A0C", borderRight: "1px solid #18181c", display: "flex", flexDirection: "column", padding: "22px 10px 20px", height: "100vh", flexShrink: 0 }}>
      <div style={{ padding: "0 8px 22px", marginBottom: 6 }}>
        <div className="oppiefi-heading" style={{ fontSize: 22, fontWeight: 800, letterSpacing: "-0.5px", color: "#fff", lineHeight: 1 }}>Oppie<span style={{ color: sec?.color || "#00E5FF" }}>-Fi</span></div>
        <div style={{ fontSize: 9, letterSpacing: "2.5px", color: "#2a2a2e", marginTop: 5, fontWeight: 600 }}>OPPORTUNITY FINDER</div>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
        {SECTIONS.map(s => (
          <button key={s.id} className={`nav-item ${active === s.id ? "active" : ""}`} onClick={() => setActive(s.id)} style={active === s.id ? { background: s.glow, borderLeftColor: s.color, color: "#fff" } : {}}>
            <span className="nav-icon">{s.icon}</span><span>{s.label}</span><span className="nav-dot" style={{ background: s.color }} />
          </button>
        ))}
      </div>
      <div style={{ flex: 1 }} />
      <div style={{ padding: "14px 8px 0", borderTop: "1px solid #18181c" }}>
        <div style={{ fontSize: 10, color: "#2a2a2e", letterSpacing: "1.5px", fontWeight: 600, marginBottom: 8 }}>YOUR INTERESTS</div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>{["Tech", "Remote", "Creative"].map(t => <span key={t} style={{ background: "#18181c", color: "#3a3a3e", fontSize: 10, padding: "3px 8px", borderRadius: 20 }}>{t}</span>)}</div>
      </div>
    </aside>
  );
}

function TopBar({ active, onSearch, user, profile, onSignOut, onChangePassword, freelanceTab }) {
  const sec = sectionFor(active); const [focused, setFocused] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const displayName = user?.user_metadata?.full_name || user?.email?.split("@")[0] || "You";
  const initial = displayName.charAt(0).toUpperCase();
  const superUser = isSuperAdmin(user, profile);
  const searchPlaceholder = getSearchHint(active, freelanceTab);
  return (
    <header style={{ height: 58, background: "#0A0A0C", borderBottom: "1px solid #18181c", display: "flex", alignItems: "center", padding: "0 24px", gap: 16, flexShrink: 0, position: "relative", zIndex: 50 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{ width: 28, height: 28, borderRadius: 8, background: sec?.glow, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15 }}>{sec?.icon}</div>
        <span className="oppiefi-heading" style={{ fontSize: 16, fontWeight: 700, color: "#fff", letterSpacing: "-0.3px" }}>{sec?.label}</span>
        {superUser ? (
          <span style={{ background: "linear-gradient(135deg, #FFD740, #FF6D00)", color: "#000", fontSize: 9, fontWeight: 800, letterSpacing: "1px", padding: "3px 8px", borderRadius: 6, marginLeft: 4 }}>OWNER</span>
        ) : isAdmin(user, profile) && (
          <span style={{ background: "#00E5FF22", color: "#00E5FF", fontSize: 9, fontWeight: 800, letterSpacing: "1px", padding: "3px 8px", borderRadius: 6, marginLeft: 4 }}>ADMIN</span>
        )}
      </div>
      <div style={{ flex: 1 }} />
      <div style={{ background: focused ? "#16161a" : "#111114", border: `1px solid ${focused ? sec?.color + "44" : "#1e1e22"}`, borderRadius: 10, padding: "7px 13px", display: "flex", gap: 8, alignItems: "center", width: 260, transition: "border-color 0.2s, background 0.2s" }}>
        <span style={{ fontSize: 13, color: "#333" }}>⌕</span>
        <input className="search-input" placeholder={searchPlaceholder} onChange={e => onSearch(e.target.value)} onFocus={() => setFocused(true)} onBlur={() => setFocused(false)} />
      </div>
      <div style={{ position: "relative" }}>
        <button type="button" onClick={() => setMenuOpen(m => !m)} title={displayName} style={{ width: 34, height: 34, borderRadius: "50%", background: `linear-gradient(135deg, ${sec?.color || "#00E5FF"}, ${sec?.color || "#00E5FF"}88)`, border: "none", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, fontWeight: 700, color: "#000", cursor: "pointer", boxShadow: `0 0 12px ${sec?.color || "#00E5FF"}44`, flexShrink: 0 }}>{initial}</button>
        {menuOpen && (
          <>
            <div style={{ position: "fixed", inset: 0, zIndex: 40 }} onClick={() => setMenuOpen(false)} />
            <div style={{ position: "absolute", right: 0, top: 42, zIndex: 50, background: "#111114", border: "1px solid #1e1e22", borderRadius: 12, padding: 8, minWidth: 200, boxShadow: "0 16px 48px #00000088" }}>
              <div style={{ padding: "10px 12px", borderBottom: "1px solid #1e1e22", marginBottom: 4 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#fff" }}>{displayName}</div>
                <div style={{ fontSize: 11, color: "#555", marginTop: 2 }}>{user?.email}</div>
              </div>
              <button type="button" onClick={() => { setMenuOpen(false); onChangePassword?.(); }} style={{ width: "100%", background: "transparent", border: "none", borderRadius: 8, padding: "10px 12px", color: "#ddd", fontSize: 13, fontWeight: 600, cursor: "pointer", textAlign: "left" }} onMouseOver={e => e.currentTarget.style.background = "#ffffff0a"} onMouseOut={e => e.currentTarget.style.background = "transparent"}>Change password</button>
              <button type="button" onClick={() => { setMenuOpen(false); onSignOut?.(); }} style={{ width: "100%", background: "transparent", border: "none", borderRadius: 8, padding: "10px 12px", color: "#FF6B6B", fontSize: 13, fontWeight: 600, cursor: "pointer", textAlign: "left" }} onMouseOver={e => e.currentTarget.style.background = "#ff6b6b14"} onMouseOut={e => e.currentTarget.style.background = "transparent"}>Sign out</button>
            </div>
          </>
        )}
      </div>
    </header>
  );
}

function SectionHeader({ section }) {
  const sec = sectionFor(section);
  return (
    <div className="fade-up" style={{ marginBottom: 24 }}>
      <div style={{ width: 32, height: 3, borderRadius: 2, background: sec?.color, marginBottom: 10 }} />
      <h1 className="oppiefi-heading" style={{ fontSize: 28, fontWeight: 800, color: "#fff", letterSpacing: "-0.8px", lineHeight: 1.1, marginBottom: 6 }}>{sec?.label}</h1>
      <p style={{ fontSize: 13, color: "#444" }}>{sec?.sub}</p>
    </div>
  );
}

// ── SECTION CARDS ────────────────────────────────────────────────────
function JobCard({ o, accent, onOpen, editMode, onEdit, onDelete }) {
  const [hover, setHover] = useState(false);
  const urgencyColor = { "closing soon": "#FFD740", "last few spots": "#FF4081", "urgent": "#FF4081" }[o.urgency] || accent;
  return (
    <div className="oppie-card" onClick={() => onOpen(o)} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} style={{ borderColor: hover ? accent + "44" : "#1e1e22", boxShadow: hover ? `0 8px 32px ${accent}18` : "none" }}>
      <AdminCardActions editMode={editMode} onEdit={onEdit} onDelete={onDelete} />
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14 }}>
        <div style={{ flex: 1, paddingRight: 12 }}>
          <div className="oppiefi-heading" style={{ fontSize: 16, fontWeight: 700, color: "#fff", letterSpacing: "-0.3px", marginBottom: 3 }}>{o.title}</div>
          <div style={{ fontSize: 12, color: "#444" }}>{o.employers?.name} · {o.employment_type}</div>
        </div>
        <Tag text={o.job_type === "remote" ? "🌐 Remote" : `📍 ${o.employers?.location || "Onsite"}`} color={accent} />
      </div>
      <div style={{ display: "flex", gap: 12, marginBottom: 12, flexWrap: "wrap" }}>
        {o.hours && <span style={{ fontSize: 11, color: "#444" }}>🕐 {o.hours}</span>}
        {o.start_date && <span style={{ fontSize: 11, color: "#444" }}>📅 {o.start_date}</span>}
        {o.hiring_timeline && <span style={{ fontSize: 11, color: "#444" }}>⏱ {o.hiring_timeline}</span>}
      </div>
      {o.perks && <p style={{ fontSize: 12, color: "#555", marginBottom: 12, lineHeight: 1.5, display: "-webkit-box", WebkitLineClamp: 1, WebkitBoxOrient: "vertical", overflow: "hidden" }}>✨ {o.perks}</p>}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingTop: 14, borderTop: "1px solid #1e1e22" }}>
        <div><div className="oppiefi-heading" style={{ fontSize: 18, fontWeight: 700, color: "#fff" }}>{o.pay || "—"}</div>{o.application_method && <div style={{ fontSize: 11, color: "#444", marginTop: 2 }}>via {o.application_method}</div>}</div>
        <span style={{ fontSize: 12, color: accent, fontWeight: 600 }}>View Role →</span>
      </div>
      <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: 3, borderRadius: "0 0 14px 14px", background: urgencyColor + "88" }} />
    </div>
  );
}
function JobsSection({ search, filters, onFilterChange, onClearFilters, onOpen, dataRefreshKey, onRetry, editMode, onEdit, onDelete }) {
  const sec = sectionFor("jobs"); const [data, setData] = useState([]); const [loading, setLoading] = useState(true); const [error, setError] = useState(null);
  useEffect(() => { (async () => { setLoading(true); setError(null); try { const { data, error } = await runQuery(() => supabase.from("job_listings").select("*, employers(name, location, website, contact_email)")); if (error) setError(`Couldn't load jobs. ${error.message}`); else setData(data || []); } catch (e) { setError(e.message); } setLoading(false); })(); }, [dataRefreshKey]);
  const filterDefs = useMemo(() => buildFilterDefs("jobs", data), [data]);
  const filtered = filterAndSearch("jobs", data, { search, filters });
  if (loading) return <LoadingGrid />; if (error) return <ErrorState msg={error} onRetry={onRetry} />;
  return (
    <>
      <FilterBar filters={filterDefs} values={filters} onChange={onFilterChange} onClear={onClearFilters} accent={sec.color} />
      {!filtered.length ? <EmptyState msg="No jobs match your search or filters." /> : <div className="card-grid">{filtered.map(o => <JobCard key={o.id} o={o} accent={sec.color} onOpen={onOpen} editMode={editMode} onEdit={() => onEdit(o)} onDelete={() => onDelete(o)} />)}</div>}
    </>
  );
}

function EduCard({ o, accent, onOpen, editMode, onEdit, onDelete }) {
  const [hover, setHover] = useState(false);
  return (
    <div className="oppie-card" onClick={() => onOpen(o)} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} style={{ borderColor: hover ? accent + "44" : "#1e1e22", boxShadow: hover ? `0 8px 32px ${accent}18` : "none" }}>
      <AdminCardActions editMode={editMode} onEdit={onEdit} onDelete={onDelete} />
      <div style={{ background: accent + "18", borderRadius: 6, padding: "4px 10px", display: "inline-block", marginBottom: 12 }}>
        <span style={{ fontSize: 10, color: accent, fontWeight: 700, letterSpacing: "1px" }}>{(o.degree_type || "COURSE").toUpperCase()}</span>
      </div>
      <div className="oppiefi-heading" style={{ fontSize: 16, fontWeight: 700, color: "#fff", letterSpacing: "-0.3px", marginBottom: 4 }}>{o.course_name || o.title}</div>
      <div style={{ fontSize: 12, color: "#444", marginBottom: 12 }}>{o.institutes?.name} · {o.institutes?.location}</div>
      <div style={{ display: "flex", gap: 12, marginBottom: 12, flexWrap: "wrap" }}>
        {o.duration && <span style={{ fontSize: 11, color: "#444" }}>⏳ {o.duration}</span>}
        {o.price && <span style={{ fontSize: 11, color: "#444" }}>💰 {o.price}</span>}
        {o.financial_aid_available && <span style={{ fontSize: 11, color: accent }}>🎓 Aid available</span>}
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingTop: 14, borderTop: "1px solid #1e1e22" }}>
        <div style={{ fontSize: 12, color: "#444" }}>
          {o.application_deadline ? `⏰ ${new Date(o.application_deadline).toLocaleDateString()}` : "⏰ Rolling"}
          {o.available_seats && <><br /><span style={{ fontSize: 11 }}>💺 {o.available_seats} seats</span></>}
        </div>
        <span style={{ fontSize: 12, color: accent, fontWeight: 600 }}>Learn More →</span>
      </div>
    </div>
  );
}
function EduSection({ search, filters, onFilterChange, onClearFilters, onOpen, dataRefreshKey, onRetry, editMode, onEdit, onDelete }) {
  const sec = sectionFor("education"); const [data, setData] = useState([]); const [loading, setLoading] = useState(true); const [error, setError] = useState(null);
  useEffect(() => { (async () => { setLoading(true); setError(null); try { const { data, error } = await runQuery(() => supabase.from("courses_and_degrees").select("*, institutes(name, location, website, contact_email)")); if (error) setError(`Couldn't load education. ${error.message}`); else setData(data || []); } catch (e) { setError(e.message); } setLoading(false); })(); }, [dataRefreshKey]);
  const filterDefs = useMemo(() => buildFilterDefs("education", data), [data]);
  const filtered = filterAndSearch("education", data, { search, filters });
  if (loading) return <LoadingGrid />; if (error) return <ErrorState msg={error} onRetry={onRetry} />;
  return (
    <>
      <FilterBar filters={filterDefs} values={filters} onChange={onFilterChange} onClear={onClearFilters} accent={sec.color} />
      {!filtered.length ? <EmptyState msg="No courses match your search or filters." /> : <div className="card-grid">{filtered.map(o => <EduCard key={o.id} o={o} accent={sec.color} onOpen={onOpen} editMode={editMode} onEdit={() => onEdit(o)} onDelete={() => onDelete(o)} />)}</div>}
    </>
  );
}

function ProjectCard({ o, accent, onOpen, editMode, onEdit, onDelete }) {
  const [hover, setHover] = useState(false); const skills = parseTags(o.skills_required);
  return (
    <div className="oppie-card" onClick={() => onOpen(o, "project")} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} style={{ borderColor: hover ? accent + "44" : "#1e1e22", borderTop: `3px solid ${accent}`, boxShadow: hover ? `0 8px 32px ${accent}18` : "none" }}>
      <AdminCardActions editMode={editMode} onEdit={onEdit} onDelete={onDelete} />
      <div style={{ fontSize: 10, color: accent, fontWeight: 700, letterSpacing: "1px", marginBottom: 10 }}>📋 PROJECT</div>
      <div className="oppiefi-heading" style={{ fontSize: 16, fontWeight: 700, color: "#fff", marginBottom: 4 }}>{o.title}</div>
      <div style={{ fontSize: 12, color: "#444", marginBottom: 10 }}>{o.client_name}{o.client_hires_before ? " · Hired before ✓" : ""}</div>
      <p style={{ fontSize: 13, color: "#555", lineHeight: 1.6, marginBottom: 14, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>{o.description}</p>
      {skills.length > 0 && <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 14 }}>{skills.map(t => <Tag key={t} text={t} />)}</div>}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingTop: 14, borderTop: "1px solid #1e1e22" }}>
        <div><div className="oppiefi-heading" style={{ fontSize: 18, fontWeight: 700, color: "#fff" }}>{o.budget_amount}</div><div style={{ fontSize: 11, color: "#444" }}>{o.budget_type} · {o.project_duration}</div></div>
        <span style={{ fontSize: 12, color: accent, fontWeight: 600 }}>View Brief →</span>
      </div>
    </div>
  );
}
function FreelancerCard({ o, onOpen, editMode, onEdit, onDelete }) {
  const [hover, setHover] = useState(false); const accent = "#8B5CF6"; const skills = parseTags(o.other_skills || o.skills);
  return (
    <div className="oppie-card" onClick={() => onOpen(o, "freelancer")} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} style={{ borderColor: hover ? accent + "44" : "#1e1e22", borderTop: `3px solid ${accent}`, boxShadow: hover ? `0 8px 32px ${accent}18` : "none" }}>
      <AdminCardActions editMode={editMode} onEdit={onEdit} onDelete={onDelete} />
      <div style={{ fontSize: 10, color: accent, fontWeight: 700, letterSpacing: "1px", marginBottom: 10 }}>👤 FREELANCER</div>
      <div className="oppiefi-heading" style={{ fontSize: 16, fontWeight: 700, color: "#fff", marginBottom: 2 }}>{o.name || o.tagline}</div>
      {o.top_skill && <div style={{ fontSize: 13, color: accent, fontWeight: 600, marginBottom: 6 }}>{o.top_skill}</div>}
      <div style={{ fontSize: 12, color: "#444", marginBottom: 10 }}>{o.availability}{o.experience_years ? ` · ${o.experience_years}` : ""}</div>
      {o.bio && <p style={{ fontSize: 12, color: "#555", lineHeight: 1.5, marginBottom: 12, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>{o.bio}</p>}
      {skills.length > 0 && <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 14 }}>{skills.map(t => <Tag key={t} text={t} />)}</div>}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingTop: 14, borderTop: "1px solid #1e1e22" }}>
        <div className="oppiefi-heading" style={{ fontSize: 18, fontWeight: 700, color: "#fff" }}>{o.hourly_rate}</div>
        <span style={{ fontSize: 12, color: accent, fontWeight: 600 }}>View Profile →</span>
      </div>
    </div>
  );
}
function FreelanceSection({ search, filters, onFilterChange, onClearFilters, onOpen, dataRefreshKey, onRetry, tab, setTab, editMode, onEdit, onDelete, onAdd, user }) {
  const sec = sectionFor("freelance"); const [projects, setProjects] = useState([]); const [freelancers, setFreelancers] = useState([]); const [loading, setLoading] = useState(true); const [error, setError] = useState(null);
  useEffect(() => { (async () => { setLoading(true); setError(null); try { const [p, f] = await Promise.all([runQuery(() => supabase.from("freelance_projects").select("*")), runQuery(() => supabase.from("freelancer_profiles").select("*"))]); if (p.error || f.error) setError(`Couldn't load freelance data. ${p.error?.message || f.error?.message}`); else { setProjects(p.data || []); setFreelancers(f.data || []); } } catch (e) { setError(e.message); } setLoading(false); })(); }, [dataRefreshKey]);
  const source = tab === "projects" ? projects : freelancers;
  const filterDefs = useMemo(() => buildFilterDefs("freelance", source, tab), [source, tab]);
  const filtered = filterAndSearch("freelance", source, { search, filters, freelanceTab: tab });
  const canManage = (item) => editMode || (user?.id && item?.created_by === user.id);
  if (loading) return <LoadingGrid />; if (error) return <ErrorState msg={error} onRetry={onRetry} />;
  return (
    <div>
      <div style={{ background: "linear-gradient(135deg, #141208, #0f0e08)", border: `1px solid ${sec.color}22`, borderRadius: 14, padding: "18px 22px", marginBottom: 22, display: "flex", justifyContent: "space-between", alignItems: "center", gap: 16 }}>
        <div>
          <div className="oppiefi-heading" style={{ fontSize: 16, fontWeight: 800, color: "#fff", marginBottom: 4 }}>{tab === "projects" ? "Need work done?" : "Offer your skills?"}</div>
          <div style={{ fontSize: 13, color: "#444" }}>{tab === "projects" ? "Post a project brief so freelancers can apply." : "Create a freelancer profile — name, skills, and contact, like signing up."}</div>
        </div>
        <button type="button" onClick={onAdd} style={{ background: sec.color, color: "#000", border: "none", borderRadius: 10, padding: "10px 20px", fontSize: 13, fontWeight: 700, cursor: "pointer", whiteSpace: "nowrap", boxShadow: `0 0 20px ${sec.color}44` }}>{tab === "projects" ? "+ Post a project" : "+ Create profile"}</button>
      </div>
      <div style={{ display: "flex", gap: 8, marginBottom: 22 }}>
        {[["projects", "📋 Browse Projects"], ["freelancers", "👤 Find Freelancers"]].map(([id, label]) => (
          <button key={id} onClick={() => setTab(id)} style={{ background: tab === id ? sec.color : "#111114", color: tab === id ? "#000" : "#444", border: `1px solid ${tab === id ? sec.color : "#1e1e22"}`, borderRadius: 9, padding: "7px 18px", fontSize: 12, fontWeight: tab === id ? 700 : 500, cursor: "pointer", transition: "all 0.15s" }}>{label}</button>
        ))}
      </div>
      <FilterBar filters={filterDefs} values={filters} onChange={onFilterChange} onClear={onClearFilters} accent={sec.color} />
      {!filtered.length ? <EmptyState msg={`No ${tab} match your search or filters.`} /> : <div className="card-grid">{tab === "projects" ? filtered.map(o => <ProjectCard key={o.id} o={o} accent={sec.color} onOpen={onOpen} editMode={canManage(o)} onEdit={() => onEdit(o, "project")} onDelete={() => onDelete(o, "project")} />) : filtered.map(o => <FreelancerCard key={o.id} o={o} onOpen={onOpen} editMode={canManage(o)} onEdit={() => onEdit(o, "freelancer")} onDelete={() => onDelete(o, "freelancer")} />)}</div>}
    </div>
  );
}

function ChallengeCard({ o, onOpen, editMode, onEdit, onDelete }) {
  const [hover, setHover] = useState(false);
  const riskColor = { low: "#69FF47", medium: "#FFD740", high: "#FF6D00", "very high": "#FF4081" };
  const color = riskColor[o.risk_level?.toLowerCase()] || "#FF6D00";
  const flames = { low: 1, medium: 2, high: 3, "very high": 5 }[o.risk_level?.toLowerCase()] || 3;
  return (
    <div className="oppie-card" onClick={() => onOpen(o)} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} style={{ background: hover ? "#1a0d08" : "#120a06", borderColor: hover ? "#FF6D0055" : "#2a1808", boxShadow: hover ? "0 12px 40px #FF6D0022" : "none", transform: hover ? "translateY(-4px)" : "none" }}>
      <AdminCardActions editMode={editMode} onEdit={onEdit} onDelete={onDelete} />
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
        <div style={{ display: "flex", gap: 8 }}><span style={{ fontSize: 10, color: "#FF6D00", fontWeight: 700, letterSpacing: "1.5px" }}>CHALLENGE</span>{o.verified && <span style={{ fontSize: 10, color: "#69FF47", fontWeight: 700 }}>✓ VERIFIED</span>}</div>
        <div style={{ display: "flex", gap: 6, alignItems: "center" }}><span>{"🔥".repeat(flames)}</span><span style={{ background: color + "22", color, fontSize: 10, padding: "2px 8px", borderRadius: 20, fontWeight: 600 }}>{o.risk_level}</span></div>
      </div>
      <div className="oppiefi-heading" style={{ fontSize: 17, fontWeight: 800, color: "#fff", letterSpacing: "-0.5px", marginBottom: 6, lineHeight: 1.25 }}>{o.title}</div>
      <div style={{ fontSize: 12, color: "#664433", marginBottom: 10 }}>{o.location && `📍 ${o.location}`}{o.duration && ` · ${o.duration}`}</div>
      <p style={{ fontSize: 13, color: "#775544", lineHeight: 1.6, marginBottom: 14, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>{o.description}</p>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingTop: 14, borderTop: "1px solid #2a1808" }}>
        <div><div className="oppiefi-heading" style={{ fontSize: 20, fontWeight: 800, color: "#FF6D00" }}>{o.reward_amount}</div>{o.reward_type && <div style={{ fontSize: 11, color: "#664433" }}>{o.reward_type}</div>}</div>
        <span style={{ fontSize: 12, color: "#FF6D00", fontWeight: 600 }}>View Challenge →</span>
      </div>
    </div>
  );
}
function ChallengesSection({ search, filters, onFilterChange, onClearFilters, onOpen, dataRefreshKey, onRetry, editMode, onEdit, onDelete }) {
  const sec = sectionFor("challenges"); const [data, setData] = useState([]); const [loading, setLoading] = useState(true); const [error, setError] = useState(null);
  useEffect(() => { (async () => { setLoading(true); setError(null); try { const { data, error } = await runQuery(() => supabase.from("crazy_challenges").select("*")); if (error) setError(`Couldn't load challenges. ${error.message}`); else setData(data || []); } catch (e) { setError(e.message); } setLoading(false); })(); }, [dataRefreshKey]);
  const filterDefs = useMemo(() => buildFilterDefs("challenges", data), [data]);
  const filtered = filterAndSearch("challenges", data, { search, filters });
  if (loading) return <LoadingGrid />; if (error) return <ErrorState msg={error} onRetry={onRetry} />;
  return (
    <>
      <FilterBar filters={filterDefs} values={filters} onChange={onFilterChange} onClear={onClearFilters} accent={sec.color} />
      {!filtered.length ? <EmptyState msg="No challenges match your search or filters." /> : <div className="card-grid">{filtered.map(o => <ChallengeCard key={o.id} o={o} onOpen={onOpen} editMode={editMode} onEdit={() => onEdit(o)} onDelete={() => onDelete(o)} />)}</div>}
    </>
  );
}

function EventCard({ o, accent, onDismiss, onOpen, editMode, onEdit, onDelete }) {
  const dateStr = o.event_date ? `${new Date(o.event_date).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })}${o.event_time ? ` · ${o.event_time}` : ""}` : "";
  return (
    <div style={{ background: "#0E110D", border: `1px solid ${accent}22`, borderLeft: `3px solid ${accent}`, borderRadius: 12, padding: "14px 18px", display: "flex", alignItems: "flex-start", gap: 14, marginBottom: 10, cursor: "pointer", transition: "background 0.2s" }} onClick={() => onOpen(o)} onMouseOver={e => e.currentTarget.style.background = "#121510"} onMouseOut={e => e.currentTarget.style.background = "#0E110D"}>
      <div style={{ width: 7, height: 7, borderRadius: "50%", background: accent, marginTop: 6, flexShrink: 0, boxShadow: `0 0 8px ${accent}` }} />
      <div style={{ flex: 1 }}>
        <div className="oppiefi-heading" style={{ fontSize: 15, fontWeight: 700, color: "#fff", marginBottom: 3 }}>{o.title}</div>
        <div style={{ fontSize: 12, color: "#444" }}>📍 {o.location} · {dateStr}</div>
        <div style={{ display: "flex", gap: 6, marginTop: 8, flexWrap: "wrap" }}>
          {o.category_tag && <Tag text={o.category_tag} />}
          {o.is_free ? <Tag text="🆓 Free" color={accent} /> : o.price && <Tag text={o.price} />}
        </div>
      </div>
      {editMode ? (
        <div onClick={e => e.stopPropagation()} style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          <button type="button" onClick={onEdit} style={{ background: "transparent", color: "#00E5FF", border: "1px solid #00E5FF44", borderRadius: 6, padding: "5px 10px", fontSize: 11, fontWeight: 700, cursor: "pointer" }}>Edit</button>
          <button type="button" onClick={onDelete} style={{ background: "transparent", color: "#FF6B6B", border: "1px solid #FF6B6B44", borderRadius: 6, padding: "5px 10px", fontSize: 11, fontWeight: 700, cursor: "pointer" }}>Delete</button>
        </div>
      ) : (
        <button onClick={e => { e.stopPropagation(); onDismiss(o.id); }} style={{ background: "transparent", color: "#2a2a2e", border: "1px solid #1e1e22", borderRadius: 6, padding: "5px 10px", fontSize: 12, cursor: "pointer" }}>✕</button>
      )}
    </div>
  );
}
function EventsSection({ search, filters, onFilterChange, onClearFilters, onOpen, dataRefreshKey, onRetry, editMode, onEdit, onDelete }) {
  const sec = sectionFor("events"); const [data, setData] = useState([]); const [dismissed, setDismissed] = useState([]); const [loading, setLoading] = useState(true); const [error, setError] = useState(null);
  useEffect(() => { (async () => { setLoading(true); setError(null); try { const { data, error } = await runQuery(() => supabase.from("local_events").select("*").order("event_date", { ascending: true })); if (error) setError(`Couldn't load events. ${error.message}`); else setData(data || []); } catch (e) { setError(e.message); } setLoading(false); })(); }, [dataRefreshKey]);
  const filterDefs = useMemo(() => buildFilterDefs("events", data), [data]);
  const filtered = filterAndSearch("events", data, { search, filters }).filter((o) => !dismissed.includes(o.id));
  if (loading) return <LoadingGrid />; if (error) return <ErrorState msg={error} onRetry={onRetry} />;
  return (
    <div>
      <FilterBar filters={filterDefs} values={filters} onChange={onFilterChange} onClear={onClearFilters} accent={sec.color} />
      <div style={{ maxWidth: 680 }}>
        {!filtered.length ? <EmptyState msg="No events match your search or filters." /> : filtered.map(o => <EventCard key={o.id} o={o} accent={sec.color} onDismiss={id => setDismissed(d => [...d, id])} onOpen={onOpen} editMode={editMode} onEdit={() => onEdit(o)} onDelete={() => onDelete(o)} />)}
      </div>
    </div>
  );
}

function StartupCard({ o, accent, onOpen, editMode, onEdit, onDelete }) {
  const [hover, setHover] = useState(false); const roles = parseTags(o.roles_needed);
  return (
    <div className="oppie-card" onClick={() => onOpen(o)} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} style={{ borderColor: hover ? accent + "44" : "#1e1e22", boxShadow: hover ? `0 8px 32px ${accent}18` : "none" }}>
      <AdminCardActions editMode={editMode} onEdit={onEdit} onDelete={onDelete} />
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
        <Tag text={o.stage || "Idea"} color={accent} />
        {o.team_space_status && <span style={{ fontSize: 10, color: o.team_space_status === "active" ? "#69FF47" : "#444" }}>{o.team_space_status === "active" ? "🟢 Active" : "⚪ Not started"}</span>}
      </div>
      <div className="oppiefi-heading" style={{ fontSize: 17, fontWeight: 800, color: "#fff", letterSpacing: "-0.5px", marginBottom: 8, lineHeight: 1.25 }}>{o.title}</div>
      {o.industry && <div style={{ fontSize: 12, color: accent, fontWeight: 600, marginBottom: 8 }}>{o.industry}</div>}
      <p style={{ fontSize: 13, color: "#555", lineHeight: 1.6, marginBottom: 14, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>{o.description}</p>
      <div style={{ display: "flex", gap: 12, marginBottom: 14, flexWrap: "wrap" }}>
        {o.founder_name && <span style={{ fontSize: 11, color: "#444" }}>👤 {o.founder_name}</span>}
        {o.time_commitment && <span style={{ fontSize: 11, color: "#444" }}>⏱ {o.time_commitment}</span>}
      </div>
      {roles.length > 0 && <div style={{ marginBottom: 14 }}><div style={{ fontSize: 10, color: "#2a2a2e", letterSpacing: "1px", marginBottom: 7 }}>LOOKING FOR</div><div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>{roles.map(r => <Tag key={r} text={r} color={accent} />)}</div></div>}
      <div style={{ paddingTop: 14, borderTop: "1px solid #1e1e22", display: "flex", justifyContent: "flex-end" }}><span style={{ fontSize: 12, color: accent, fontWeight: 600 }}>View Idea →</span></div>
    </div>
  );
}
function EntreSection({ search, filters, onFilterChange, onClearFilters, onOpen, dataRefreshKey, onRetry, editMode, onEdit, onDelete, onAdd }) {
  const sec = sectionFor("entrepreneur"); const [data, setData] = useState([]); const [loading, setLoading] = useState(true); const [error, setError] = useState(null);
  useEffect(() => { (async () => { setLoading(true); setError(null); try { const { data, error } = await runQuery(() => supabase.from("startup_ideas").select("*")); if (error) setError(`Couldn't load ideas. ${error.message}`); else setData(data || []); } catch (e) { setError(e.message); } setLoading(false); })(); }, [dataRefreshKey]);
  const filterDefs = useMemo(() => buildFilterDefs("entrepreneur", data), [data]);
  const filtered = filterAndSearch("entrepreneur", data, { search, filters });
  if (loading) return <LoadingGrid />; if (error) return <ErrorState msg={error} onRetry={onRetry} />;
  return (
    <div>
      <div style={{ background: "linear-gradient(135deg, #1a0810, #0f0815)", border: `1px solid ${sec.color}22`, borderRadius: 14, padding: "18px 22px", marginBottom: 22, display: "flex", justifyContent: "space-between", alignItems: "center", gap: 16 }}>
        <div><div className="oppiefi-heading" style={{ fontSize: 16, fontWeight: 800, color: "#fff", marginBottom: 4 }}>Have a wild startup idea?</div><div style={{ fontSize: 13, color: "#444" }}>Post it. Find co-founders. No upfront commitment.</div></div>
        <button type="button" onClick={() => editMode && onAdd?.()} style={{ background: sec.color, color: "#fff", border: "none", borderRadius: 10, padding: "10px 20px", fontSize: 13, fontWeight: 700, cursor: editMode ? "pointer" : "default", whiteSpace: "nowrap", boxShadow: `0 0 20px ${sec.color}44`, opacity: editMode ? 1 : 0.55 }}>{editMode ? "+ Post Idea" : "+ Post Idea"}</button>
      </div>
      <FilterBar filters={filterDefs} values={filters} onChange={onFilterChange} onClear={onClearFilters} accent={sec.color} />
      {!filtered.length ? <EmptyState msg="No startups match your search or filters." /> : <div className="card-grid">{filtered.map(o => <StartupCard key={o.id} o={o} accent={sec.color} onOpen={onOpen} editMode={editMode} onEdit={() => onEdit(o)} onDelete={() => onDelete(o)} />)}</div>}
    </div>
  );
}

// ── ROOT APP ─────────────────────────────────────────────────────────
export default function OppiFi({ user, profile, onSignOut, onRepairSession, onChangePassword, dataRefreshKey = 0 }) {
  const [active, setActive] = useState("jobs");
  const [search, setSearch] = useState("");
  const [filtersBySection, setFiltersBySection] = useState({});
  const [freelanceTab, setFreelanceTab] = useState("projects");
  const [detail, setDetail] = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [editor, setEditor] = useState(null);
  const [manageAdminsOpen, setManageAdminsOpen] = useState(false);
  const [mutationKey, setMutationKey] = useState(0);
  const staff = isAdmin(user, profile);
  const mainAdmin = isSuperAdmin(user, profile);
  const canEdit = staff && editMode;
  const refreshKey = `${dataRefreshKey}-${mutationKey}`;
  const bumpListings = () => setMutationKey((k) => k + 1);
  const sec = sectionFor(active);
  const openDetail = (item, subType = null) => setDetail({ item, subType });
  const closeDetail = () => setDetail(null);
  const currentKind = listingKindFor(active, freelanceTab);

  const openEditor = (item = null, subType = null) => {
    const tab = subType === "freelancer" ? "freelancers" : subType === "project" ? "projects" : freelanceTab;
    setEditor({ kind: listingKindFor(active, tab), item });
  };

  const handleDelete = async (item, subType = null) => {
    if (!item?.id) return;
    if (!window.confirm("Delete this listing? This cannot be undone.")) return;
    const tab = subType === "freelancer" ? "freelancers" : subType === "project" ? "projects" : freelanceTab;
    try {
      await deleteListing(listingKindFor(active, tab), item.id);
      closeDetail();
      bumpListings();
    } catch (err) {
      window.alert(err.message || "Could not delete listing.");
    }
  };

  const sectionFilters = filtersBySection[active] || {};
  const setFilter = (key, value) => {
    setFiltersBySection((prev) => ({
      ...prev,
      [active]: { ...(prev[active] || {}), [key]: value },
    }));
  };
  const clearFilters = () => {
    setFiltersBySection((prev) => ({ ...prev, [active]: {} }));
  };

  const retryLoad = () => {
    onRepairSession?.();
  };

  const renderSection = () => {
    const s = search.toLowerCase();
    const shared = {
      dataRefreshKey: refreshKey,
      onRetry: retryLoad,
      search: s,
      filters: sectionFilters,
      onFilterChange: setFilter,
      onClearFilters: clearFilters,
      editMode: canEdit,
      onEdit: openEditor,
      onDelete: handleDelete,
    };
    switch (active) {
      case "jobs":         return <JobsSection       onOpen={openDetail} {...shared} />;
      case "education":    return <EduSection        onOpen={openDetail} {...shared} />;
      case "freelance":    return <FreelanceSection  onOpen={openDetail} tab={freelanceTab} setTab={(t) => { setFreelanceTab(t); setFiltersBySection((prev) => ({ ...prev, freelance: {} })); }} onAdd={() => openEditor(null)} user={user} {...shared} />;
      case "challenges":   return <ChallengesSection onOpen={openDetail} {...shared} />;
      case "events":       return <EventsSection      onOpen={openDetail} {...shared} />;
      case "entrepreneur": return <EntreSection       onOpen={openDetail} onAdd={() => openEditor(null)} {...shared} />;
      default:             return null;
    }
  };

  const renderDetail = () => {
    if (!detail) return null;
    const { item, subType } = detail;
    const accent = sec.color;
    const ownListing = Boolean(item?.created_by && user?.id && item.created_by === user.id);
    const admin = (canEdit || ownListing)
      ? {
          enabled: true,
          onEdit: () => {
            openEditor(item, subType);
          },
          onDelete: () => handleDelete(item, subType),
        }
      : null;
    switch (active) {
      case "jobs":         return <JobDetail        o={item} accent={accent}    onClose={closeDetail} admin={admin} />;
      case "education":    return <EduDetail        o={item} accent={accent}    onClose={closeDetail} admin={admin} />;
      case "freelance":    return subType === "freelancer"
                             ? <FreelancerDetail   o={item} accent="#8B5CF6"   onClose={closeDetail} admin={admin} />
                             : <ProjectDetail      o={item} accent={accent}    onClose={closeDetail} admin={admin} />;
      case "challenges":   return <ChallengeDetail o={item} accent={accent}    onClose={closeDetail} admin={admin} />;
      case "events":       return <EventDetail     o={item} accent={accent}    onClose={closeDetail} admin={admin} />;
      case "entrepreneur": return <StartupDetail   o={item} accent={accent}    onClose={closeDetail} admin={admin} />;
      default:             return null;
    }
  };

  return (
    <>
      <style>{GLOBAL_CSS}</style>
      <div style={{ display: "flex", height: "100vh", background: "#0D0D0F", overflow: "hidden" }}>
        <Sidebar active={active} setActive={s => { setActive(s); setSearch(""); setDetail(null); }} />
        <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
          <TopBar active={active} onSearch={setSearch} user={user} profile={profile} onSignOut={onSignOut} onChangePassword={onChangePassword} freelanceTab={freelanceTab} />
          <main style={{ flex: 1, overflowY: "auto", padding: "28px 28px 80px" }}>
            {canEdit && (
              <div style={{ background: "#00E5FF12", border: "1px solid #00E5FF33", borderRadius: 12, padding: "10px 14px", marginBottom: 18, fontSize: 13, color: "#00E5FF" }}>
                Edit mode is on. Add, change, or delete listings. Turn it off to browse like everyone else.
              </div>
            )}
            <SectionHeader section={active} key={active} />
            {renderSection()}
          </main>
        </div>
      </div>
      {staff && (
        <AdminDock
          editMode={editMode}
          onToggle={() => setEditMode((v) => !v)}
          isMainAdmin={mainAdmin}
          onAdd={() => openEditor(null)}
          onManageAdmins={() => setManageAdminsOpen(true)}
        />
      )}
      {detail && renderDetail()}
      {editor && (
        <ListingEditor
          kind={editor.kind || currentKind}
          item={editor.item}
          user={user}
          profile={profile}
          onClose={() => setEditor(null)}
          onSaved={() => {
            setEditor(null);
            closeDetail();
            bumpListings();
          }}
        />
      )}
      {manageAdminsOpen && mainAdmin && <ManageAdmins onClose={() => setManageAdminsOpen(false)} />}
    </>
  );
}
