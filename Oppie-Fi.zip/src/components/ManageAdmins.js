import { useEffect, useState } from "react";
import { demoteAdmin, fetchStaffAccounts, promoteToAdmin } from "../lib/admin";

export default function ManageAdmins({ onClose }) {
  const [email, setEmail] = useState("");
  const [staff, setStaff] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const load = async () => {
    setLoading(true);
    setError("");
    try {
      const rows = await fetchStaffAccounts();
      setStaff(rows || []);
    } catch (err) {
      setError(err.message || "Could not load admins. Run the admin SQL in Supabase first.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const handlePromote = async (e) => {
    e.preventDefault();
    setError("");
    setMessage("");
    setBusy(true);
    try {
      await promoteToAdmin(email);
      setMessage(`${email.trim()} is now an admin. They can edit listings, but cannot create more admins.`);
      setEmail("");
      await load();
    } catch (err) {
      setError(err.message || "Could not create admin.");
    } finally {
      setBusy(false);
    }
  };

  const handleDemote = async (id, label) => {
    if (!window.confirm(`Remove admin access for ${label}?`)) return;
    setError("");
    setBusy(true);
    try {
      await demoteAdmin(id);
      await load();
    } catch (err) {
      setError(err.message || "Could not remove admin.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div role="dialog" aria-modal="true" style={{ position: "fixed", inset: 0, zIndex: 220, display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
      <div style={{ position: "absolute", inset: 0, background: "#000000cc", backdropFilter: "blur(8px)" }} onClick={onClose} />
      <div className="overlay-in" style={{ position: "relative", width: "100%", maxWidth: 480, background: "#111114", border: "1px solid #1e1e22", borderRadius: 18, padding: "28px 24px", boxShadow: "0 24px 80px #000000aa" }}>
        <button type="button" onClick={onClose} style={{ position: "absolute", top: 14, right: 14, background: "#18181c", border: "1px solid #1e1e22", borderRadius: 8, width: 32, height: 32, color: "#666", cursor: "pointer", fontSize: 16 }} aria-label="Close">×</button>
        <div className="oppiefi-heading" style={{ fontSize: 22, fontWeight: 800, color: "#fff", marginBottom: 6 }}>Manage admins</div>
        <p style={{ fontSize: 13, color: "#555", marginBottom: 20 }}>Only the main admin can add or remove staff. They must already have an Oppie-Fi account.</p>

        <form onSubmit={handlePromote} style={{ display: "flex", gap: 8, marginBottom: 18 }}>
          <input
            type="email"
            required
            placeholder="Account email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            style={{ flex: 1, background: "#0D0D0F", border: "1px solid #1e1e22", borderRadius: 10, padding: "11px 14px", color: "#ddd", fontSize: 14, outline: "none" }}
          />
          <button type="submit" disabled={busy} style={{ background: "#FFD740", color: "#000", border: "none", borderRadius: 10, padding: "11px 14px", fontSize: 13, fontWeight: 800, cursor: busy ? "wait" : "pointer", whiteSpace: "nowrap" }}>
            Make admin
          </button>
        </form>

        {error && <div style={{ fontSize: 13, color: "#FF6B6B", background: "#ff6b6b14", padding: "10px 12px", borderRadius: 8, marginBottom: 12 }}>{error}</div>}
        {message && <div style={{ fontSize: 13, color: "#69FF47", background: "#69ff4714", padding: "10px 12px", borderRadius: 8, marginBottom: 12 }}>{message}</div>}

        <div style={{ fontSize: 10, letterSpacing: "1.5px", color: "#333", fontWeight: 700, marginBottom: 10 }}>STAFF</div>
        {loading ? (
          <div style={{ fontSize: 13, color: "#555" }}>Loading…</div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 8, maxHeight: 280, overflowY: "auto" }}>
            {staff.map((row) => {
              const label = row.email || row.full_name || row.id;
              const isMain = row.role === "super_admin";
              return (
                <div key={row.id} style={{ display: "flex", alignItems: "center", gap: 10, background: "#0D0D0F", border: "1px solid #1e1e22", borderRadius: 10, padding: "10px 12px" }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, color: "#fff", fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis" }}>{label}</div>
                    <div style={{ fontSize: 11, color: isMain ? "#FFD740" : "#00E5FF" }}>{isMain ? "Main admin" : "Admin"}</div>
                  </div>
                  {!isMain && (
                    <button type="button" disabled={busy} onClick={() => handleDemote(row.id, label)} style={{ background: "transparent", border: "1px solid #FF6B6B44", color: "#FF6B6B", borderRadius: 8, padding: "6px 10px", fontSize: 11, fontWeight: 700, cursor: "pointer" }}>
                      Remove
                    </button>
                  )}
                </div>
              );
            })}
            {!staff.length && <div style={{ fontSize: 13, color: "#555" }}>No staff rows yet.</div>}
          </div>
        )}
      </div>
    </div>
  );
}
