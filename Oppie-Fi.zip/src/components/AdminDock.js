export default function AdminDock({
  editMode,
  onToggle,
  isMainAdmin,
  onAdd,
  onManageAdmins,
}) {
  return (
    <div style={{ position: "fixed", right: 22, bottom: 22, zIndex: 90, display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 10 }}>
      {isMainAdmin && (
        <button
          type="button"
          onClick={onManageAdmins}
          title="Create other admin accounts"
          style={{ background: "#111114", border: "1px solid #FFD74055", color: "#FFD740", borderRadius: 12, padding: "10px 14px", fontSize: 12, fontWeight: 700, cursor: "pointer", boxShadow: "0 8px 28px #00000088" }}
        >
          Manage admins
        </button>
      )}
      {editMode && (
        <button
          type="button"
          onClick={onAdd}
          style={{ background: "#00E5FF", color: "#000", border: "none", borderRadius: 12, padding: "10px 16px", fontSize: 13, fontWeight: 800, cursor: "pointer", fontFamily: "'Syne', sans-serif", boxShadow: "0 8px 28px #00E5FF44" }}
        >
          + Add listing
        </button>
      )}
      <button
        type="button"
        onClick={onToggle}
        aria-pressed={editMode}
        title={editMode ? "Turn off to browse like everyone else" : "Turn on to add, edit, or delete listings"}
        style={{
          width: 58,
          height: 58,
          borderRadius: "50%",
          border: editMode ? "2px solid #00E5FF" : "1px solid #2a2a2e",
          background: editMode ? "linear-gradient(135deg, #00E5FF, #00B8D4)" : "#111114",
          color: editMode ? "#000" : "#888",
          fontSize: 11,
          fontWeight: 800,
          cursor: "pointer",
          boxShadow: editMode ? "0 0 28px #00E5FF66" : "0 8px 28px #00000088",
          letterSpacing: "0.4px",
        }}
      >
        {editMode ? "ON" : "EDIT"}
      </button>
    </div>
  );
}
