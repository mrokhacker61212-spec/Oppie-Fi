import { useEffect, useState } from "react";
import { LISTING_SCHEMAS } from "../constants/listingFields";
import { emptyForm, formFromItem, saveListing } from "../lib/admin";

const inputStyle = {
  width: "100%",
  background: "#0D0D0F",
  border: "1px solid #1e1e22",
  borderRadius: 10,
  padding: "11px 14px",
  color: "#ddd",
  fontSize: 14,
  outline: "none",
  fontFamily: "'DM Sans', sans-serif",
};

export function AdminCardActions({ editMode, onEdit, onDelete }) {
  if (!editMode) return null;
  return (
    <div
      onClick={(e) => e.stopPropagation()}
      style={{ display: "flex", gap: 6, marginBottom: 12, justifyContent: "flex-end" }}
    >
      <button
        type="button"
        onClick={onEdit}
        style={{ background: "#18181c", border: "1px solid #00E5FF55", borderRadius: 8, padding: "5px 10px", color: "#00E5FF", fontSize: 11, fontWeight: 700, cursor: "pointer" }}
      >
        Edit
      </button>
      <button
        type="button"
        onClick={onDelete}
        style={{ background: "#18181c", border: "1px solid #FF6B6B55", borderRadius: 8, padding: "5px 10px", color: "#FF6B6B", fontSize: 11, fontWeight: 700, cursor: "pointer" }}
      >
        Delete
      </button>
    </div>
  );
}

export default function ListingEditor({ kind, item, user, profile, onClose, onSaved }) {
  const schema = LISTING_SCHEMAS[kind];
  const [form, setForm] = useState(() => {
    const base = item ? formFromItem(kind, item) : emptyForm(kind);
    if (!item && kind === "freelancers") {
      base.name = profile?.full_name || user?.user_metadata?.full_name || "";
      base.contact_value = user?.email || "";
      base.preferred_contact = base.preferred_contact || "Email";
    }
    if (!item && kind === "freelance_projects") {
      base.client_name = profile?.full_name || user?.user_metadata?.full_name || "";
      base.client_contact = user?.email || "";
    }
    return base;
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const base = item ? formFromItem(kind, item) : emptyForm(kind);
    if (!item && kind === "freelancers") {
      base.name = profile?.full_name || user?.user_metadata?.full_name || "";
      base.contact_value = user?.email || "";
      base.preferred_contact = base.preferred_contact || "Email";
    }
    if (!item && kind === "freelance_projects") {
      base.client_name = profile?.full_name || user?.user_metadata?.full_name || "";
      base.client_contact = user?.email || "";
    }
    setForm(base);
  }, [kind, item, user, profile]);

  useEffect(() => {
    const fn = (e) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", fn);
    return () => window.removeEventListener("keydown", fn);
  }, [onClose]);

  if (!schema) return null;

  const set = (key, value) => setForm((prev) => ({ ...prev, [key]: value }));

  const handleSave = async (e) => {
    e.preventDefault();
    setError("");
    setSaving(true);
    try {
      await saveListing(kind, item, form, { userId: user?.id });
      onSaved?.();
    } catch (err) {
      setError(err.message || "Could not save listing.");
    } finally {
      setSaving(false);
    }
  };

  const renderField = (f, valueKey = f.key) => {
    const value = form[valueKey];
    if (f.type === "checkbox") {
      return (
        <label key={valueKey} style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 13, color: "#aaa" }}>
          <input type="checkbox" checked={Boolean(value)} onChange={(e) => set(valueKey, e.target.checked)} />
          {f.label}
        </label>
      );
    }
    if (f.type === "textarea") {
      return (
        <label key={valueKey} style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          <span style={{ fontSize: 11, color: "#555", fontWeight: 600 }}>{f.label}{f.required ? " *" : ""}</span>
          <textarea
            rows={4}
            required={Boolean(f.required)}
            style={{ ...inputStyle, resize: "vertical", lineHeight: 1.6 }}
            value={value || ""}
            onChange={(e) => set(valueKey, e.target.value)}
          />
        </label>
      );
    }
    return (
      <label key={valueKey} style={{ display: "flex", flexDirection: "column", gap: 6 }}>
        <span style={{ fontSize: 11, color: "#555", fontWeight: 600 }}>{f.label}{f.required ? " *" : ""}</span>
        <input
          type={f.type === "date" ? "date" : f.type === "number" ? "number" : "text"}
          required={Boolean(f.required)}
          style={inputStyle}
          value={value || ""}
          onChange={(e) => set(valueKey, e.target.value)}
        />
      </label>
    );
  };

  return (
    <div role="dialog" aria-modal="true" style={{ position: "fixed", inset: 0, zIndex: 220, display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
      <div style={{ position: "absolute", inset: 0, background: "#000000cc", backdropFilter: "blur(8px)" }} onClick={onClose} />
      <form
        onSubmit={handleSave}
        className="overlay-in"
        style={{ position: "relative", width: "100%", maxWidth: 560, maxHeight: "90vh", overflowY: "auto", background: "#111114", border: "1px solid #1e1e22", borderRadius: 18, padding: "28px 24px", boxShadow: "0 24px 80px #000000aa" }}
      >
        <button type="button" onClick={onClose} style={{ position: "absolute", top: 14, right: 14, background: "#18181c", border: "1px solid #1e1e22", borderRadius: 8, width: 32, height: 32, color: "#666", cursor: "pointer", fontSize: 16 }} aria-label="Close">×</button>
        <div className="oppiefi-heading" style={{ fontSize: 22, fontWeight: 800, color: "#fff", marginBottom: 6 }}>
          {item?.id ? `Edit ${schema.label}` : kind === "freelancers" ? "Create your freelancer profile" : `Add ${schema.label}`}
        </div>
        <p style={{ fontSize: 13, color: "#555", marginBottom: 20 }}>
          {kind === "freelancers" && !item?.id
            ? "Enter your details the same way as signing up — name, skills, and how people can reach you."
            : kind === "freelance_projects" && !item?.id
              ? "Fill in the project brief so freelancers know what you need and how to apply."
              : "Changes go live for everyone as soon as you save."}
        </p>

        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {schema.related && (
            <>
              <div style={{ fontSize: 10, letterSpacing: "1.5px", color: "#333", fontWeight: 700 }}>RELATED</div>
              {schema.related.fields.map((f) => renderField(f, `rel_${f.key}`))}
            </>
          )}
          <div style={{ fontSize: 10, letterSpacing: "1.5px", color: "#333", fontWeight: 700, marginTop: schema.related ? 8 : 0 }}>LISTING</div>
          {schema.fields.map((f) => renderField(f))}
        </div>

        {error && <div style={{ marginTop: 14, fontSize: 13, color: "#FF6B6B", background: "#ff6b6b14", padding: "10px 12px", borderRadius: 8 }}>{error}</div>}

        <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
          <button type="button" onClick={onClose} style={{ flex: 1, background: "#18181c", border: "1px solid #1e1e22", borderRadius: 12, padding: "13px", color: "#888", fontSize: 14, fontWeight: 600, cursor: "pointer" }}>Cancel</button>
          <button type="submit" disabled={saving} style={{ flex: 1, background: "linear-gradient(135deg, #00E5FF, #00B8D4)", color: "#000", border: "none", borderRadius: 12, padding: "13px", fontSize: 14, fontWeight: 800, cursor: saving ? "wait" : "pointer", fontFamily: "'Syne', sans-serif", opacity: saving ? 0.7 : 1 }}>
            {saving ? "Saving…" : "Save listing"}
          </button>
        </div>
      </form>
    </div>
  );
}
