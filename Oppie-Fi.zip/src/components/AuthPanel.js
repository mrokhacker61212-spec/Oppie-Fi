import { useState } from "react";
import { supabase } from "../lib/supabase";
import {
  explainAuthError,
  requestPasswordReset,
  signInWithGoogle,
  updatePassword,
  verifyRecoveryOtp,
  verifyRecoveryTokenHash,
} from "../lib/auth";

const inputStyle = {
  width: "100%",
  background: "#0D0D0F",
  border: "1px solid #1e1e22",
  borderRadius: 10,
  padding: "12px 14px",
  color: "#ddd",
  fontSize: 14,
  outline: "none",
  fontFamily: "'DM Sans', sans-serif",
};

function PasswordField({ value, onChange, placeholder, autoComplete, required, minLength }) {
  const [visible, setVisible] = useState(false);
  return (
    <div style={{ position: "relative" }}>
      <input
        style={{ ...inputStyle, paddingRight: 44 }}
        type={visible ? "text" : "password"}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        required={required}
        minLength={minLength}
        autoComplete={autoComplete}
      />
      <button
        type="button"
        onClick={() => setVisible((v) => !v)}
        aria-label={visible ? "Hide password" : "Show password"}
        style={{ position: "absolute", right: 10, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", color: "#666", cursor: "pointer", fontSize: 12, fontWeight: 600, padding: 4 }}
      >
        {visible ? "Hide" : "Show"}
      </button>
    </div>
  );
}

export default function AuthPanel({
  mode: initialMode = "signin",
  recovery = false,
  tokenHash = "",
  initialError = "",
  onClose,
  onSuccess,
}) {
  const [mode, setMode] = useState(tokenHash ? "confirm-reset" : initialMode);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [otp, setOtp] = useState("");
  const [resetSent, setResetSent] = useState(false);
  const [fullName, setFullName] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(initialError);
  const [message, setMessage] = useState("");

  const handleGoogle = async () => {
    setError("");
    setLoading(true);
    try {
      await signInWithGoogle();
    } catch (err) {
      setError(explainAuthError(err) || "Google sign-in failed. Enable Google in Supabase → Authentication → Providers.");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setMessage("");
    setLoading(true);

    try {
      if (mode === "signin") {
        const { error: err } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (err) throw err;
        onSuccess?.();
      } else if (mode === "signup") {
        const { data, error: err } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: { data: { full_name: fullName.trim() } },
        });
        if (err) throw err;
        if (data?.user && !data.session) {
          setMessage("Check your email to confirm your account, then sign in.");
          setMode("signin");
        } else {
          onSuccess?.();
        }
      } else if (mode === "confirm-reset") {
        await verifyRecoveryTokenHash(tokenHash);
        onSuccess?.();
      } else if (mode === "reset") {
        if (resetSent) {
          if (!otp.trim()) throw new Error("Enter the 6-digit code from your email.");
          await verifyRecoveryOtp(email, otp);
          onSuccess?.();
        } else {
          await requestPasswordReset(email);
          setResetSent(true);
          setMessage("Email sent. Ignore the old link if it says expired. Enter the 6-digit code from the new email, then you can set a password.");
        }
      } else if (mode === "update") {
        if (password.length < 6) throw new Error("Password must be at least 6 characters.");
        if (password !== confirmPassword) throw new Error("Passwords do not match.");
        await updatePassword(password);
        onSuccess?.();
      }
    } catch (err) {
      setError(explainAuthError(err));
    } finally {
      setLoading(false);
    }
  };

  const titles = {
    signin: "Welcome back",
    signup: "Create your account",
    reset: resetSent ? "Enter reset code" : "Reset password",
    update: recovery ? "Choose a new password" : "Change password",
    "confirm-reset": "Reset password",
  };

  const submitLabel = loading
    ? "Please wait…"
    : mode === "signin"
      ? "Sign in"
      : mode === "signup"
        ? "Create account"
        : mode === "confirm-reset"
          ? "Continue"
          : mode === "reset"
            ? (resetSent ? "Verify code" : "Send reset email")
            : "Save new password";

  return (
    <div role="dialog" aria-modal="true" style={{ position: "fixed", inset: 0, zIndex: 200, display: "flex", alignItems: "center", justifyContent: "center", padding: 24, background: "#0D0D0F" }}>
      <style>{`@keyframes overlayIn { from { opacity: 0; transform: scale(0.98) translateY(10px); } to { opacity: 1; transform: scale(1) translateY(0); } } .overlay-in { animation: overlayIn 0.25s cubic-bezier(0.16,1,0.3,1) forwards; }`}</style>
      <div style={{ position: "absolute", inset: 0, background: "#000000cc", backdropFilter: "blur(8px)" }} onClick={recovery ? undefined : onClose} />
      <div className="overlay-in" style={{ position: "relative", width: "100%", maxWidth: 420, background: "#111114", border: "1px solid #1e1e22", borderRadius: 18, padding: "32px 28px", boxShadow: "0 24px 80px #000000aa" }}>
        {!recovery && (
          <button type="button" onClick={onClose} style={{ position: "absolute", top: 14, right: 14, background: "#18181c", border: "1px solid #1e1e22", borderRadius: 8, width: 32, height: 32, color: "#666", cursor: "pointer", fontSize: 16 }} aria-label="Close">×</button>
        )}

        <div className="oppiefi-heading" style={{ fontSize: 24, fontWeight: 800, color: "#fff", marginBottom: 6, letterSpacing: "-0.5px" }}>{titles[mode]}</div>
        <p style={{ fontSize: 13, color: "#555", marginBottom: 24 }}>
          {mode === "signin" && "Sign in to browse jobs, courses, challenges, and more."}
          {mode === "signup" && "Join Oppie-Fi to save opportunities and apply with one account."}
          {mode === "reset" && !resetSent && "We'll email a 6-digit code (and a link). Prefer the code — inbox scanners often break the link."}
          {mode === "reset" && resetSent && "Open the newest email and type the 6-digit code. Keep this tab open."}
          {mode === "confirm-reset" && "This tab will verify your reset request. Click Continue, then choose a new password."}
          {mode === "update" && (recovery ? "Set a new password to finish signing in." : "Enter a new password for this account.")}
        </p>

        <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {mode === "signup" && (
            <input style={inputStyle} type="text" placeholder="Full name" value={fullName} onChange={e => setFullName(e.target.value)} required autoComplete="name" />
          )}
          {mode !== "update" && mode !== "confirm-reset" && (
            <input style={inputStyle} type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} required autoComplete="email" />
          )}
          {mode === "reset" && resetSent && (
            <input
              style={{ ...inputStyle, letterSpacing: "4px", fontSize: 18, textAlign: "center" }}
              type="text"
              inputMode="numeric"
              autoComplete="one-time-code"
              placeholder="6-digit code"
              value={otp}
              onChange={e => setOtp(e.target.value.replace(/\D/g, "").slice(0, 8))}
              required
            />
          )}
          {(mode === "signin" || mode === "signup" || mode === "update") && (
            <PasswordField
              placeholder={mode === "update" ? "New password (min. 6 characters)" : "Password (min. 6 characters)"}
              value={password}
              onChange={e => setPassword(e.target.value)}
              required
              minLength={6}
              autoComplete={mode === "signin" ? "current-password" : "new-password"}
            />
          )}
          {mode === "update" && (
            <PasswordField
              placeholder="Confirm new password"
              value={confirmPassword}
              onChange={e => setConfirmPassword(e.target.value)}
              required
              minLength={6}
              autoComplete="new-password"
            />
          )}

          {error && <div style={{ fontSize: 13, color: "#FF6B6B", background: "#ff6b6b14", padding: "10px 12px", borderRadius: 8 }}>{error}</div>}
          {message && <div style={{ fontSize: 13, color: "#69FF47", background: "#69ff4714", padding: "10px 12px", borderRadius: 8 }}>{message}</div>}

          <button type="submit" disabled={loading} style={{ marginTop: 8, background: "linear-gradient(135deg, #00E5FF, #00B8D4)", color: "#000", border: "none", borderRadius: 12, padding: "14px", fontSize: 15, fontWeight: 700, cursor: loading ? "wait" : "pointer", fontFamily: "'Syne', sans-serif", opacity: loading ? 0.7 : 1 }}>
            {submitLabel}
          </button>
        </form>

        {mode !== "reset" && mode !== "update" && mode !== "confirm-reset" && (
          <>
            <div style={{ display: "flex", alignItems: "center", gap: 12, margin: "20px 0 16px" }}>
              <div style={{ flex: 1, height: 1, background: "#1e1e22" }} />
              <span style={{ fontSize: 11, color: "#444", fontWeight: 600 }}>OR</span>
              <div style={{ flex: 1, height: 1, background: "#1e1e22" }} />
            </div>
            <button type="button" onClick={handleGoogle} disabled={loading} style={{ width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: 10, background: "#fff", border: "none", borderRadius: 12, padding: "13px", fontSize: 14, fontWeight: 600, color: "#333", cursor: loading ? "wait" : "pointer" }}>
              <svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true"><path fill="#FFC107" d="M43.611 20.083H42V20H24v8h11.303C33.654 32.657 29.073 36 24 36c-6.627 0-12-5.373-12-12s5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C33.64 6.053 28.991 4 24 4 12.955 4 4 12.955 4 24s8.955 20 20 20 20-8.955 20-20c0-1.341-.138-2.65-.389-3.917z"/><path fill="#FF3D00" d="M6.306 14.691l6.571 4.819C14.655 15.108 18.961 12 24 12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C33.64 6.053 28.991 4 24 4 16.318 4 9.656 8.337 6.306 14.691z"/><path fill="#4CAF50" d="M24 44c5.166 0 9.86-1.977 13.409-5.192l-6.19-5.238C29.211 35.091 26.715 36 24 36c-5.202 0-9.619-3.317-11.283-7.946l-6.522 5.025C9.505 39.556 16.227 44 24 44z"/><path fill="#1976D2" d="M43.611 20.083H42V20H24v8h11.303a12.04 12.04 0 0 1-4.087 5.571l.003-.002 6.19 5.238C36.971 39.205 44 34 44 24c0-1.341-.138-2.65-.389-3.917z"/></svg>
              Continue with Google
            </button>
          </>
        )}

        <div style={{ marginTop: 20, fontSize: 13, color: "#555", textAlign: "center" }}>
          {mode === "signin" && (
            <>
              <button type="button" onClick={() => { setMode("reset"); setResetSent(false); setOtp(""); setError(""); setMessage(""); }} style={{ background: "none", border: "none", color: "#888", cursor: "pointer", textDecoration: "underline", fontSize: 13 }}>Forgot password?</button>
              <div style={{ marginTop: 12 }}>No account?{" "}
                <button type="button" onClick={() => { setMode("signup"); setError(""); setMessage(""); }} style={{ background: "none", border: "none", color: "#00E5FF", cursor: "pointer", fontWeight: 600, fontSize: 13 }}>Sign up</button>
              </div>
            </>
          )}
          {mode === "signup" && (
            <>Already have an account?{" "}
              <button type="button" onClick={() => { setMode("signin"); setError(""); setMessage(""); }} style={{ background: "none", border: "none", color: "#00E5FF", cursor: "pointer", fontWeight: 600, fontSize: 13 }}>Sign in</button>
            </>
          )}
          {mode === "reset" && resetSent && (
            <button type="button" onClick={() => { setResetSent(false); setOtp(""); setError(""); setMessage(""); }} style={{ background: "none", border: "none", color: "#888", cursor: "pointer", fontSize: 13, marginRight: 12 }}>Send a new code</button>
          )}
          {(mode === "reset" || mode === "confirm-reset") && (
            <button type="button" onClick={() => { setMode("signin"); setResetSent(false); setError(""); setMessage(""); onClose?.(); }} style={{ background: "none", border: "none", color: "#00E5FF", cursor: "pointer", fontWeight: 600, fontSize: 13 }}>← Back to sign in</button>
          )}
          {mode === "update" && (
            <button type="button" onClick={onClose} style={{ background: "none", border: "none", color: "#888", cursor: "pointer", fontSize: 13 }}>
              {recovery ? "Cancel and sign out" : "Cancel"}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
