import { useState, useEffect, useMemo } from "react";
import { supabase, runQuery } from "../lib/supabase";
import { SECTIONS, COUNT_QUERIES } from "../constants/sections";
import AuthPanel from "./AuthPanel";

const HOME_CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:ital,wght@0,300;0,400;0,500;0,600;1,400&display=swap');
  .home-root { min-height: 100vh; background: #0D0D0F; color: #fff; font-family: 'DM Sans', sans-serif; overflow-x: hidden; overflow-y: auto; }
  .oppiefi-heading { font-family: 'Syne', sans-serif; }
  @keyframes orbFloat { 0%, 100% { transform: translate(0, 0) scale(1); } 50% { transform: translate(30px, -20px) scale(1.05); } }
  @keyframes ticker { 0% { transform: translateX(0); } 100% { transform: translateX(-50%); } }
  @keyframes fadeUp { from { opacity: 0; transform: translateY(16px); } to { opacity: 1; transform: translateY(0); } }
  @keyframes pulseGlow { 0%, 100% { opacity: 0.4; } 50% { opacity: 0.7; } }
  .fade-up { animation: fadeUp 0.6s ease forwards; }
  .home-orb { position: absolute; border-radius: 50%; filter: blur(80px); animation: orbFloat 12s ease-in-out infinite; pointer-events: none; }
  .ticker-track { display: flex; gap: 12px; width: max-content; animation: ticker 40s linear infinite; }
  .ticker-wrap:hover .ticker-track { animation-play-state: paused; }
  .section-card { background: #111114; border: 1px solid #1e1e22; border-radius: 14px; padding: 20px; transition: transform 0.2s, border-color 0.2s, box-shadow 0.2s; }
  .section-card:hover { transform: translateY(-4px); }
`;

const FEATURED_FETCHERS = [
  { type: "job", table: "job_listings", select: "id, title, pay, employers(name)", label: "💼" },
  { type: "edu", table: "courses_and_degrees", select: "id, course_name, institutes(name)", label: "🎓" },
  { type: "challenge", table: "crazy_challenges", select: "id, title, reward_amount", label: "🔥" },
  { type: "event", table: "local_events", select: "id, title, location", label: "📍" },
];

function formatFeatured(item) {
  if (item.course_name) return { text: item.course_name, sub: item.institutes?.name, label: "🎓" };
  if (item.reward_amount) return { text: item.title, sub: item.reward_amount, label: "🔥" };
  if (item.location && !item.pay) return { text: item.title, sub: item.location, label: "📍" };
  return { text: item.title, sub: item.employers?.name || item.pay || "New listing", label: "💼" };
}

export default function HomePage({ dataRefreshKey = 0 }) {
  const [counts, setCounts] = useState({});
  const [featured, setFeatured] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState("signin");
  const [hoveredSection, setHoveredSection] = useState(null);

  const openAuth = (mode = "signin") => {
    setAuthMode(mode);
    setAuthOpen(true);
  };

  const loadHomeData = async (cancelledRef) => {
    setLoading(true);
    try {
      const countResults = await Promise.all(
        COUNT_QUERIES.map(async ({ key, table }) => {
          const { count, error } = await runQuery(() =>
            supabase.from(table).select("*", { count: "exact", head: true })
          );
          if (error) throw error;
          return [key, count ?? 0];
        })
      );
      const featuredResults = await Promise.all(
        FEATURED_FETCHERS.map(async ({ table, select }) => {
          const { data, error } = await runQuery(() =>
            supabase.from(table).select(select).limit(3)
          );
          if (error) throw error;
          return data || [];
        })
      );
      if (cancelledRef.current) return;
      setLoadError("");
      setCounts(Object.fromEntries(countResults));
      const items = featuredResults.flat().map((row) => formatFeatured(row));
      setFeatured(
        items.length
          ? items
          : [
              { label: "💼", text: "Remote developer roles", sub: "Updated daily" },
              { label: "🎓", text: "Scholarships & courses", sub: "Worldwide programs" },
              { label: "🔥", text: "High-reward challenges", sub: "For the bold" },
            ]
      );
    } catch (err) {
      if (!cancelledRef.current) {
        console.warn("Homepage data load failed:", err);
        setLoadError(err.message || "Could not load opportunities from Supabase.");
      }
    } finally {
      if (!cancelledRef.current) setLoading(false);
    }
  };

  useEffect(() => {
    const cancelled = { current: false };
    loadHomeData(cancelled);
    return () => {
      cancelled.current = true;
    };
  }, [dataRefreshKey]);

  const totalOpportunities = useMemo(
    () => Object.values(counts).reduce((a, b) => a + b, 0),
    [counts]
  );

  const tickerItems = [...featured, ...featured];

  return (
    <div className="home-root">
      <style>{HOME_CSS}</style>

      <div className="home-orb" style={{ width: 420, height: 420, background: "#00E5FF22", top: "-10%", left: "-5%", animationDelay: "0s" }} />
      <div className="home-orb" style={{ width: 360, height: 360, background: "#FF408122", bottom: "10%", right: "-8%", animationDelay: "-4s" }} />
      <div className="home-orb" style={{ width: 280, height: 280, background: "#B388FF18", top: "40%", left: "40%", animationDelay: "-7s" }} />

      <header style={{ position: "sticky", top: 0, zIndex: 50, backdropFilter: "blur(12px)", background: "#0D0D0Ff0", borderBottom: "1px solid #18181c" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", padding: "16px 24px", display: "flex", alignItems: "center", gap: 16 }}>
          <div className="oppiefi-heading" style={{ fontSize: 22, fontWeight: 800, letterSpacing: "-0.5px" }}>
            Oppie<span style={{ color: "#00E5FF" }}>-Fi</span>
          </div>
          <div style={{ flex: 1 }} />
          <button type="button" onClick={() => openAuth("signin")} style={{ background: "transparent", border: "1px solid #2a2a2e", borderRadius: 10, padding: "9px 18px", color: "#aaa", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>Sign in</button>
          <button type="button" onClick={() => openAuth("signup")} style={{ background: "linear-gradient(135deg, #00E5FF, #00B8D4)", border: "none", borderRadius: 10, padding: "9px 20px", color: "#000", fontSize: 13, fontWeight: 700, cursor: "pointer", boxShadow: "0 0 24px #00E5FF44" }}>Get started</button>
        </div>
      </header>

      <main style={{ maxWidth: 1100, margin: "0 auto", padding: "48px 24px 80px", position: "relative", zIndex: 1 }}>
        <section className="fade-up" style={{ textAlign: "center", marginBottom: 56, animationDelay: "0.05s" }}>
          <div style={{ display: "inline-block", background: "#00E5FF14", border: "1px solid #00E5FF33", borderRadius: 20, padding: "6px 14px", fontSize: 11, fontWeight: 700, letterSpacing: "1.5px", color: "#00E5FF", marginBottom: 20 }}>
            OPPORTUNITY FINDER
          </div>
          <h1 className="oppiefi-heading" style={{ fontSize: "clamp(36px, 6vw, 56px)", fontWeight: 800, lineHeight: 1.08, letterSpacing: "-2px", marginBottom: 18 }}>
            Every opportunity.<br />
            <span style={{ background: "linear-gradient(90deg, #00E5FF, #B388FF, #FF4081)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>One place.</span>
          </h1>
          <p style={{ fontSize: 16, color: "#666", maxWidth: 520, margin: "0 auto 32px", lineHeight: 1.7 }}>
            Jobs, education, freelance gigs, wild challenges, local events, and startup ideas — browse, save, and apply after you sign in.
          </p>
          <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
            <button type="button" onClick={() => openAuth("signup")} style={{ background: "linear-gradient(135deg, #00E5FF, #00B8D4)", border: "none", borderRadius: 12, padding: "14px 28px", color: "#000", fontSize: 15, fontWeight: 700, cursor: "pointer", fontFamily: "'Syne', sans-serif" }}>Create free account →</button>
            <button type="button" onClick={() => openAuth("signin")} style={{ background: "#111114", border: "1px solid #1e1e22", borderRadius: 12, padding: "14px 28px", color: "#ccc", fontSize: 15, fontWeight: 600, cursor: "pointer" }}>I already have an account</button>
          </div>
        </section>

        {loadError && (
          <div style={{ background: "#2a1810", border: "1px solid #FF6D0044", borderRadius: 12, padding: "14px 18px", marginBottom: 24, fontSize: 13, color: "#FF9E6D" }}>
            ⚠ {loadError} — Try refreshing the page. If it keeps happening, sign out and sign back in.
          </div>
        )}

        <section style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: 14, marginBottom: 48 }} className="fade-up">
          {loading
            ? SECTIONS.map(s => (
              <div key={s.id} style={{ background: "#111114", borderRadius: 14, height: 88, border: "1px solid #1e1e22" }} />
            ))
            : (
              <>
                <div style={{ gridColumn: "1 / -1", background: "linear-gradient(135deg, #111114, #16161a)", border: "1px solid #1e1e22", borderRadius: 14, padding: "20px 24px", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
                  <div>
                    <div className="oppiefi-heading" style={{ fontSize: 28, fontWeight: 800, color: "#fff" }}>{totalOpportunities.toLocaleString()}+</div>
                    <div style={{ fontSize: 13, color: "#555" }}>live opportunities across all categories</div>
                  </div>
                  <div style={{ fontSize: 12, color: "#00E5FF", fontWeight: 600 }}>↻ Refreshes from your database</div>
                </div>
                {SECTIONS.map(s => (
                  <div key={s.id} style={{ background: "#111114", border: `1px solid ${hoveredSection === s.id ? s.color + "55" : "#1e1e22"}`, borderRadius: 14, padding: "16px 18px", transition: "border-color 0.2s" }} onMouseEnter={() => setHoveredSection(s.id)} onMouseLeave={() => setHoveredSection(null)}>
                    <div style={{ fontSize: 22, marginBottom: 8 }}>{s.icon}</div>
                    <div className="oppiefi-heading" style={{ fontSize: 22, fontWeight: 800, color: s.color }}>{loading ? "—" : (counts[s.id] ?? 0)}</div>
                    <div style={{ fontSize: 11, color: "#555", marginTop: 2 }}>{s.label}</div>
                  </div>
                ))}
              </>
            )}
        </section>

        {featured.length > 0 && (
          <section style={{ marginBottom: 48, overflow: "hidden" }} className="ticker-wrap fade-up">
            <div style={{ fontSize: 10, letterSpacing: "1.5px", color: "#333", fontWeight: 600, marginBottom: 12, textTransform: "uppercase" }}>Live from Oppie-Fi</div>
            <div style={{ overflow: "hidden", maskImage: "linear-gradient(90deg, transparent, #000 8%, #000 92%, transparent)" }}>
              <div className="ticker-track">
                {tickerItems.map((item, i) => (
                  <div key={i} style={{ flexShrink: 0, background: "#111114", border: "1px solid #1e1e22", borderRadius: 10, padding: "10px 16px", display: "flex", alignItems: "center", gap: 10, minWidth: 220 }}>
                    <span>{item.label}</span>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 600, color: "#ddd" }}>{item.text}</div>
                      <div style={{ fontSize: 11, color: "#555" }}>{item.sub}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>
        )}

        <section className="fade-up" style={{ marginBottom: 48 }}>
          <h2 className="oppiefi-heading" style={{ fontSize: 24, fontWeight: 800, marginBottom: 8, letterSpacing: "-0.5px" }}>Six worlds to explore</h2>
          <p style={{ fontSize: 14, color: "#555", marginBottom: 24 }}>Sign in to browse full listings, details, and apply.</p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 14 }}>
            {SECTIONS.map(s => (
              <div
                key={s.id}
                className="section-card"
                style={{ borderColor: hoveredSection === s.id ? s.color + "44" : "#1e1e22", boxShadow: hoveredSection === s.id ? `0 12px 40px ${s.glow}` : "none" }}
                onMouseEnter={() => setHoveredSection(s.id)}
                onMouseLeave={() => setHoveredSection(null)}
              >
                <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
                  <span style={{ fontSize: 20 }}>{s.icon}</span>
                  <span className="oppiefi-heading" style={{ fontSize: 17, fontWeight: 700, color: "#fff" }}>{s.label}</span>
                </div>
                <p style={{ fontSize: 13, color: "#666", lineHeight: 1.6, marginBottom: 14 }}>{s.sub}</p>
                <div style={{ fontSize: 12, color: s.color, fontWeight: 600 }}>{loading ? "Loading…" : `${counts[s.id] ?? 0} open · Sign in to browse →`}</div>
              </div>
            ))}
          </div>
        </section>

        <section className="fade-up" style={{ background: "linear-gradient(135deg, #0a1218, #120a14)", border: "1px solid #1e1e22", borderRadius: 18, padding: "40px 32px", textAlign: "center" }}>
          <h2 className="oppiefi-heading" style={{ fontSize: 26, fontWeight: 800, marginBottom: 10 }}>Ready to find your next move?</h2>
          <p style={{ fontSize: 14, color: "#555", marginBottom: 24 }}>Free to join. Your session stays signed in securely via Supabase.</p>
          <button type="button" onClick={() => openAuth("signup")} style={{ background: "linear-gradient(135deg, #00E5FF, #00B8D4)", border: "none", borderRadius: 12, padding: "14px 32px", color: "#000", fontSize: 15, fontWeight: 700, cursor: "pointer", fontFamily: "'Syne', sans-serif" }}>Sign up & start browsing →</button>
        </section>
      </main>

      {authOpen && (
        <AuthPanel
          mode={authMode}
          onClose={() => setAuthOpen(false)}
          onSuccess={() => setAuthOpen(false)}
        />
      )}
    </div>
  );
}
