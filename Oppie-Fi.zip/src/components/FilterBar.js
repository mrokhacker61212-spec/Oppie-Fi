import { useState } from "react";

export default function FilterBar({ filters = [], values = {}, onChange, accent = "#00E5FF", onClear }) {
  const [open, setOpen] = useState(false);
  const activeCount = Object.values(values).filter((v) => v && v !== "all").length;

  if (!filters.length) return null;

  return (
    <div style={{ marginBottom: 20 }}>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        style={{
          background: open ? accent + "18" : "#111114",
          border: `1px solid ${open ? accent + "44" : "#1e1e22"}`,
          borderRadius: 10,
          padding: "8px 14px",
          color: open ? accent : "#888",
          fontSize: 12,
          fontWeight: 600,
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          gap: 8,
        }}
      >
        <span>▾ Filters</span>
        {activeCount > 0 && (
          <span style={{ background: accent, color: "#000", borderRadius: 20, padding: "1px 8px", fontSize: 10, fontWeight: 800 }}>
            {activeCount}
          </span>
        )}
      </button>

      {open && (
        <div
          style={{
            marginTop: 12,
            background: "#111114",
            border: "1px solid #1e1e22",
            borderRadius: 12,
            padding: "16px 18px",
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))",
            gap: 14,
          }}
        >
          {filters.map((f) => (
            <label key={f.key} style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              <span style={{ fontSize: 10, color: "#555", fontWeight: 600, letterSpacing: "0.5px", textTransform: "uppercase" }}>{f.label}</span>
              <select
                value={values[f.key] || "all"}
                onChange={(e) => onChange(f.key, e.target.value)}
                style={{
                  background: "#0D0D0F",
                  border: "1px solid #1e1e22",
                  borderRadius: 8,
                  padding: "8px 10px",
                  color: "#ccc",
                  fontSize: 13,
                  outline: "none",
                  fontFamily: "'DM Sans', sans-serif",
                }}
              >
                {f.options.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </label>
          ))}
          {activeCount > 0 && (
            <div style={{ display: "flex", alignItems: "flex-end" }}>
              <button
                type="button"
                onClick={onClear}
                style={{
                  background: "transparent",
                  border: "1px solid #2a2a2e",
                  borderRadius: 8,
                  padding: "8px 12px",
                  color: "#666",
                  fontSize: 12,
                  cursor: "pointer",
                  width: "100%",
                }}
              >
                Clear filters
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
