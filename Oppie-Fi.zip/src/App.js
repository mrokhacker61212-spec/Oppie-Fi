import { useState, useEffect } from "react";
import { supabase, recoverSession, initSessionWatch, notifyDataRefresh } from "./lib/supabase";
import {
  clearPasswordRecovery,
  fetchUserProfile,
  formatAuthCallbackError,
  isPasswordRecoveryPending,
  markPasswordRecovery,
  readAuthCallback,
} from "./lib/auth";
import OppiFi from "./OppiFi";
import HomePage from "./components/HomePage";
import AuthPanel from "./components/AuthPanel";

function AuthLoading() {
  return (
    <div style={{ minHeight: "100vh", background: "#0D0D0F", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 16 }}>
      <div className="oppiefi-heading" style={{ fontFamily: "'Syne', sans-serif", fontSize: 28, fontWeight: 800, color: "#fff" }}>
        Oppie<span style={{ color: "#00E5FF" }}>-Fi</span>
      </div>
      <div style={{ width: 32, height: 32, border: "2px solid #1e1e22", borderTopColor: "#00E5FF", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

export default function App() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [dataRefreshKey, setDataRefreshKey] = useState(0);
  const [passwordRecovery, setPasswordRecovery] = useState(() => isPasswordRecoveryPending());
  const [changePasswordOpen, setChangePasswordOpen] = useState(false);
  const [resetLinkError, setResetLinkError] = useState(() => formatAuthCallbackError());
  const [pendingTokenHash, setPendingTokenHash] = useState(() => {
    const callback = readAuthCallback();
    if (callback.error || callback.errorCode) return "";
    return callback.tokenHash;
  });

  const bumpDataRefresh = () => setDataRefreshKey((k) => k + 1);

  useEffect(() => {
    let cancelled = false;
    let timeoutId;

    const finishLoading = () => {
      if (timeoutId) window.clearTimeout(timeoutId);
      if (!cancelled) setLoading(false);
    };

    timeoutId = window.setTimeout(finishLoading, 8000);

    supabase.auth
      .getSession()
      .then(({ data: { session: s } }) => {
        if (cancelled) return;
        setSession(s);
        finishLoading();
      })
      .catch((err) => {
        console.warn("Auth session check failed:", err);
        finishLoading();
      });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, s) => {
      if (cancelled) return;

      setSession(s);

      if (event === "PASSWORD_RECOVERY" || (event === "SIGNED_IN" && isPasswordRecoveryPending())) {
        markPasswordRecovery();
        setPasswordRecovery(true);
        setResetLinkError("");
        setPendingTokenHash("");
      }

      if (event === "SIGNED_OUT") {
        setProfile(null);
        setPasswordRecovery(false);
        clearPasswordRecovery();
      }

      if (event === "SIGNED_IN" || event === "TOKEN_REFRESHED" || event === "INITIAL_SESSION") {
        bumpDataRefresh();
      }
    });

    const stopWatch = initSessionWatch(bumpDataRefresh);

    return () => {
      cancelled = true;
      if (timeoutId) window.clearTimeout(timeoutId);
      subscription.unsubscribe();
      stopWatch();
    };
  }, []);

  useEffect(() => {
    let cancelled = false;

    if (!session?.user) {
      setProfile(null);
      return undefined;
    }

    (async () => {
      const profileData = await fetchUserProfile(session.user.id);
      if (!cancelled) setProfile(profileData);
    })();

    return () => {
      cancelled = true;
    };
  }, [session?.user?.id, dataRefreshKey]);

  const handleSignOut = async () => {
    clearPasswordRecovery();
    setPasswordRecovery(false);
    await supabase.auth.signOut();
    setSession(null);
    setProfile(null);
  };

  const handleSessionRepair = async () => {
    const refreshed = await recoverSession();
    const { data: { session: s } } = await supabase.auth.getSession();
    setSession(refreshed || s);
    if (refreshed || s) {
      notifyDataRefresh();
      bumpDataRefresh();
    }
  };

  if (loading) return <AuthLoading />;

  if (pendingTokenHash) {
    return (
      <AuthPanel
        tokenHash={pendingTokenHash}
        onClose={() => {
          setPendingTokenHash("");
          clearPasswordRecovery();
        }}
        onSuccess={() => {
          setPendingTokenHash("");
          setResetLinkError("");
          markPasswordRecovery();
          setPasswordRecovery(true);
        }}
      />
    );
  }

  if (resetLinkError && !session) {
    return (
      <AuthPanel
        mode="reset"
        initialError={resetLinkError}
        onClose={() => {
          setResetLinkError("");
          clearPasswordRecovery();
        }}
        onSuccess={() => {
          setResetLinkError("");
          markPasswordRecovery();
          setPasswordRecovery(true);
        }}
      />
    );
  }

  if (passwordRecovery) {
    if (!session) {
      return (
        <AuthPanel
          mode="reset"
          onClose={() => {
            clearPasswordRecovery();
            setPasswordRecovery(false);
          }}
          onSuccess={() => {}}
        />
      );
    }

    return (
      <AuthPanel
        mode="update"
        recovery
        onClose={handleSignOut}
        onSuccess={() => {
          clearPasswordRecovery();
          setPasswordRecovery(false);
          bumpDataRefresh();
        }}
      />
    );
  }

  if (!session) {
    return <HomePage dataRefreshKey={dataRefreshKey} />;
  }

  return (
    <>
      <OppiFi
        user={session.user}
        profile={profile}
        onSignOut={handleSignOut}
        onRepairSession={handleSessionRepair}
        onChangePassword={() => setChangePasswordOpen(true)}
        dataRefreshKey={dataRefreshKey}
      />
      {changePasswordOpen && (
        <AuthPanel
          mode="update"
          onClose={() => setChangePasswordOpen(false)}
          onSuccess={() => setChangePasswordOpen(false)}
        />
      )}
    </>
  );
}
