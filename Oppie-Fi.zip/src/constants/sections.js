export const SECTIONS = [
  { id: "jobs",         label: "Jobs",             icon: "💼", color: "#00E5FF", glow: "#00E5FF33", sub: "Every kind of job. Remote, onsite, everywhere." },
  { id: "education",    label: "Education",        icon: "🎓", color: "#B388FF", glow: "#B388FF33", sub: "Scholarships, admissions, courses & foreign programs." },
  { id: "freelance",    label: "Freelance",        icon: "⚡", color: "#FFD740", glow: "#FFD74033", sub: "Browse projects to take on, or find talent to hire." },
  { id: "challenges",   label: "Crazy Challenges", icon: "🔥", color: "#FF6D00", glow: "#FF6D0033", sub: "High-risk, high-reward. For the bold." },
  { id: "events",       label: "Events",           icon: "📍", color: "#69FF47", glow: "#69FF4733", sub: "Discover events by name, place, and category." },
  { id: "entrepreneur", label: "Entrepreneur Hub", icon: "🚀", color: "#FF4081", glow: "#FF408133", sub: "Post wild ideas. Find co-founders. Build something." },
];

export const COUNT_QUERIES = [
  { key: "jobs", table: "job_listings" },
  { key: "education", table: "courses_and_degrees" },
  { key: "freelance", table: "freelance_projects" },
  { key: "challenges", table: "crazy_challenges" },
  { key: "events", table: "local_events" },
  { key: "entrepreneur", table: "startup_ideas" },
];
