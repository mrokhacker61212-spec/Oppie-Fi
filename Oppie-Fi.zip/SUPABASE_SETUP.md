# Supabase setup for Oppie-Fi

Project: `kvvywixmawlrqfwiutna`

## 1. Enable email authentication

1. Go to **Authentication** → **Providers**
2. Open **Email**
3. Turn **Enable Email provider** ON
4. For local development, you can turn **Confirm email** OFF so sign-up works instantly without checking inbox
5. For production, keep **Confirm email** ON and use a real inbox

## 2. Set site URL (required)

1. Go to **Authentication** → **URL Configuration**
2. Set **Site URL** to:
   - Dev: `http://localhost:3000`
   - Production: your deployed URL (e.g. `https://your-app.vercel.app`)
3. Under **Redirect URLs**, add:
   - `http://localhost:3000/**`
   - Your production URL with `/**` if you deploy later

## 3. Google sign-in (required for “Continue with Google”)

### A. Google Cloud Console

1. Go to [Google Cloud Console](https://console.cloud.google.com/) → **APIs & Services** → **Credentials**
2. **Create Credentials** → **OAuth client ID** → type **Web application**
3. **Authorized JavaScript origins:** `http://localhost:3000` (and your production URL later)
4. **Authorized redirect URIs:**  
   `https://kvvywixmawlrqfwiutna.supabase.co/auth/v1/callback`
5. Copy the **Client ID** and **Client Secret**

### B. Supabase Dashboard

1. **Authentication** → **Providers** → **Google** → Enable
2. Paste Client ID and Client Secret → **Save**

Google login uses real OAuth via Supabase — same as email auth for sessions.

## 4. Super admin (site owner)

Your owner email is registered in the database: **`mrokhacker837@gmail.com`**

When you sign up or sign in with that email (password or Google), you get:

- **`super_admin`** role on your profile
- **OWNER** badge in the app header
- Full database access via RLS policies
- A floating **EDIT** button: off = browse like anyone else; on = add, edit, or delete listings in every category
- **Manage admins** — promote an existing account to **admin**. Those admins can edit listings but **cannot** create more admins

To use a different email, run in **SQL Editor**:

```sql
INSERT INTO public.super_admins (email) VALUES ('your-email@gmail.com')
ON CONFLICT (email) DO NOTHING;
```

Optional: set `REACT_APP_SUPER_ADMIN_EMAIL=your-email@gmail.com` in a `.env` file for the UI badge fallback.

### Staff admin policies (required for this feature)

Run `supabase/admin_policies.sql` in the SQL Editor first, then `supabase/freelance_user_listings.sql` so any signed-in user can post freelance projects and freelancer profiles (and edit or delete their own).

- Lets `super_admin` and `admin` insert/update/delete listings
- Lets only the main admin call `promote_to_admin` / `demote_admin`

An admin account must already exist (they sign up first). Then the owner enters their email in **Manage admins**.

## 5. Password reset (forgot password)

Keep the app running (`npm start`) before you open a reset email. If localhost is off, the browser shows “This site can’t be reached.”

Gmail/Outlook often **pre-click** the default reset link, which makes Supabase return `otp_expired`. Use a **6-digit code** instead.

1. **Authentication** → **URL Configuration**
   - Site URL: `http://localhost:3000` (or your production URL)
   - Redirect URLs: `http://localhost:3000/**`
2. **Authentication** → **Providers** → **Email** ON
3. **Authentication** → **Email Templates** → **Reset password** — replace the body with:

```html
<h2>Reset your password</h2>
<p>Use this code in Oppie-Fi (recommended):</p>
<p style="font-size:24px;letter-spacing:4px"><strong>{{ .Token }}</strong></p>
<p>Or <a href="{{ .SiteURL }}/?token_hash={{ .TokenHash }}&type=recovery">continue in the app</a>, then click Continue. Do not use an old email.</p>
```

4. In the app: **Forgot password?** → send email → type the code → set a new password
5. Signed-in users: avatar menu → **Change password**

If no email arrives: check spam, Email provider, Auth rate limits, and custom SMTP.

## 6. Test a user

1. Run the app: `npm start`
2. Open `http://localhost:3000`
3. Click **Get started** → create account with email + password (min. 6 characters)
4. After sign-in you should land on the category browser
5. Click your avatar (top right) → **Sign out** to return to the homepage

## 7. Troubleshooting

| Issue | Fix |
|-------|-----|
| "Invalid login credentials" | Wrong email/password, or user not confirmed |
| "Email not confirmed" | Confirm via email, or disable confirm in Supabase for dev |
| Sign-up works but no session | Email confirmation is on — check inbox or disable confirm |
| Reset password link fails / `otp_expired` | Keep `npm start` running. Ignore the old link. Update the Reset password email template to include `{{ .Token }}`, then enter that 6-digit code in the app. |
| **Error sending recovery email** | Supabase SMTP/template failed (500). Check **Logs → Auth**. Disable broken Custom SMTP, or revert the Reset password template. Set the password under **Authentication → Users** until mail works. |
| Counts show 0 on homepage | Tables empty or RLS blocks anonymous `select` |
| **Couldn't load jobs/education** (403) | Fixed in DB: `authenticated` role now has SELECT on listing tables. Sign out and back in if still broken. |
| Google button does nothing | Enable Google provider in Supabase + set redirect URI in Google Cloud |
| No OWNER badge | Sign in with `mrokhacker837@gmail.com` (or email in `super_admins` table) |

### Allow public read for homepage stats (optional)

If live counts stay at 0 but data exists, your tables may block anonymous reads. For each listing table:

```sql
create policy "Public read listings"
  on public.job_listings for select
  to anon, authenticated
  using (true);
```

Repeat for `courses_and_degrees`, `freelance_projects`, `crazy_challenges`, `local_events`, `startup_ideas` as needed.
